package course.leedev.cn.pubgassistant.model.request;

import android.support.annotation.NonNull;

import course.leedev.cn.pubgassistant.base.BaseModel;
import course.leedev.cn.pubgassistant.contract.request.RequestContract;

/**
 * Created by lt on 2017/12/30.
 *
 * 助手主页 model
 */

public class RequestModel extends BaseModel implements RequestContract.IRequestModel {

    @NonNull
    public static RequestModel newInstance() {
        return new RequestModel();
    }

    @Override
    public String[] getTabs() {
        return new String[]{"新请求", "新回复"};
    }

}
