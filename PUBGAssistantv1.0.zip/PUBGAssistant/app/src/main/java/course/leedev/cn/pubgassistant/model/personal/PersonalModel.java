package course.leedev.cn.pubgassistant.model.personal;

import android.support.annotation.NonNull;

import course.leedev.cn.pubgassistant.base.BaseModel;
import course.leedev.cn.pubgassistant.contract.personal.PersonalContract;

/**
 * Created by lt on 2017/12/30.
 *
 * 助手主页 model
 */

public class PersonalModel extends BaseModel implements PersonalContract.IPersonalModel {

    @NonNull
    public static PersonalModel newInstance() {
        return new PersonalModel();
    }

    @Override
    public String[] getTabs() {
        return new String[]{"我的宠物"};
    } //

}
