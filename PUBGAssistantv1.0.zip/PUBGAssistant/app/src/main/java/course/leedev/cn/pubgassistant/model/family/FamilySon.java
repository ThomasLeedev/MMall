package course.leedev.cn.pubgassistant.model.family;

import cn.bmob.v3.BmobObject;

public class FamilySon extends BmobObject {

    String petId;
    String sonId;

    public String getPetId() {
        return petId;
    }

    public void setPetId(String petId) {
        this.petId = petId;
    }

    public String getSonId() {
        return sonId;
    }

    public void setSonId(String sonId) {
        this.sonId = sonId;
    }
}
