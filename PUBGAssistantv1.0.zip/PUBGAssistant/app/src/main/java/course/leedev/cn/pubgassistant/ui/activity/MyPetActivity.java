package course.leedev.cn.pubgassistant.ui.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.vondear.rxtools.RxClipboardTool;
import com.vondear.rxtools.RxDataTool;
import com.vondear.rxtools.view.RxQRCode;
import com.vondear.rxtools.view.RxToast;
import com.vondear.rxtools.view.dialog.RxDialogEditSureCancel;
import com.vondear.rxtools.view.dialog.RxDialogSure;
import com.vondear.rxtools.view.dialog.RxDialogSureCancel;

import java.io.File;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.datatype.BmobFile;
import cn.bmob.v3.listener.DeleteListener;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.GetListener;
import cn.bmob.v3.listener.SaveListener;
import cn.bmob.v3.listener.UpdateListener;
import cn.bmob.v3.listener.UploadFileListener;
import course.leedev.cn.pubgassistant.R;
import course.leedev.cn.pubgassistant.base.activity.BaseActivity;
import course.leedev.cn.pubgassistant.global.GlobalApplication;
import course.leedev.cn.pubgassistant.model.User;
import course.leedev.cn.pubgassistant.model.family.FamilyDaughter;
import course.leedev.cn.pubgassistant.model.family.FamilySon;
import course.leedev.cn.pubgassistant.model.family.FamilyWife;
import course.leedev.cn.pubgassistant.model.pet;
import course.leedev.cn.pubgassistant.utils.AgeUtils;
import de.hdodenhof.circleimageview.CircleImageView;

import static course.leedev.cn.pubgassistant.global.GlobalApplication.getContext;

/**
 * Created by lt on 18-6-17.
 */

public class MyPetActivity extends BaseActivity {

    @BindView(R.id.pet_iv_avatar)
    CircleImageView avatar;
    @BindView(R.id.pet_tv_age)
    TextView age;
    @BindView(R.id.pet_tv_category)
    TextView category;
    @BindView(R.id.pet_tv_name)
    TextView name;
    @BindView(R.id.pet_iv_user_avatar)
    CircleImageView userAvatar;
    @BindView(R.id.pet_ll_host)
    LinearLayout petHost;
    @BindView(R.id.pet_iv_qrcode)
    ImageView petQrCode;
    @BindView(R.id.pet_iv_wife_avatar)
    CircleImageView mIvWifeAvatar;
    @BindView(R.id.pet_iv_son_avatar)
    CircleImageView mIvSonAvatar;
    @BindView(R.id.pet_iv_daughter_avatar)
    CircleImageView mIvDaughterAvatar;

    private User pet_user;
    private FamilyWife mFamilyWife;
    private FamilySon mFamilySon;
    private FamilyDaughter mFamilyDdaughter;
    pet mPet;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_pet;
    }

    @Override
    protected void initView(Bundle savedInstanceState) {

        final Intent intent = getIntent();
        final Bundle bundle = intent.getBundleExtra("pet");
        mPet = (course.leedev.cn.pubgassistant.model.pet) bundle.getSerializable("pet");

        Glide.with(this).load(mPet.getAvatar()).into(avatar);

        name.setText(mPet.getName());
        category.setText(mPet.getCategory());

        if (mPet.getGender().equals("雄性")) {
            age.setText("♂ " + AgeUtils.getAgeFromBirthTime(mPet.getBirthday()));
            age.setBackground(getResources().getDrawable(R.drawable.shape_gender));
        } else {
            age.setText("♀ " + AgeUtils.getAgeFromBirthTime(mPet.getBirthday()));
        }

        RxQRCode.createQRCode(mPet.getObjectId(), petQrCode);

        petQrCode.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                final RxDialogSure rxDialog = new RxDialogSure(MyPetActivity.this);
                rxDialog.setTitle("保存图片到相册");
                rxDialog.setContent("");
                rxDialog.setSure("保存");
                rxDialog.setSureListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //图片保存
                        MediaStore.Images.Media.insertImage(getContentResolver(), RxQRCode.creatQRCode(mPet.getObjectId(), 400, 400), mPet.getName()+".jpg", "qrcode");
                        sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(new File("/sdcard/Boohee/image.jpg"))));
                        rxDialog.dismiss();
                        RxToast.normal("保存成功");
                    }
                });
                rxDialog.show();
                return true;
            }
        });
//        BmobQuery<User> query = new BmobQuery<User>();
//        query.getObject(getContext(), pet.getUserid(), new GetListener<User>() {
//            @Override
//            public void onSuccess(final User user) {
//
//                Glide.with(getContext()).load(user.getAvatar()).into(userAvatar);
//                petHost.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        Intent intent1 = new Intent(getContext(), UserActivity.class);
//                        Bundle bundle1 = new Bundle();
//                        bundle1.putSerializable("user", user);
//                        intent1.putExtra("user", bundle1);
//                        startActivity(intent1);
//                    }
//                });
//            }
//
//            @Override
//            public void onFailure(int i, String s) {
//                RxToast.normal("出现问题！请稍后重试！");
//            }
//        });

        getUserInfo(mPet);

        setWifeFamily(mPet);
        setSonFamily(mPet);
        setDaughterFamily(mPet);

        addLongClick();
    }

    /**
     * 关联关系设置Wife, Son, Daughter
     * @param myPet
     */
    private void setDaughterFamily(pet myPet) {
        BmobQuery<FamilyDaughter> wife = new BmobQuery<>();
        wife.addWhereEqualTo("petId", myPet.getObjectId());
        wife.findObjects(this, new FindListener<FamilyDaughter>() {
            @Override
            public void onSuccess(List<FamilyDaughter> list) {
                if (!list.isEmpty()) {
                    mFamilyDdaughter = list.get(0);
                    BmobQuery<pet> petOb = new BmobQuery<>();
                    petOb.getObject(MyPetActivity.this, list.get(0).getDaughterId(), new GetListener<course.leedev.cn.pubgassistant.model.pet>() {
                        @Override
                        public void onSuccess(final pet pet) {
                            Glide.with(MyPetActivity.this).load(pet.getAvatar()).into(mIvDaughterAvatar);

                            mIvDaughterAvatar.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent intent = new Intent(getContext(), PetActivity.class);
                                    Bundle bundle = new Bundle();
                                    bundle.putSerializable("pet", pet);
                                    intent.putExtra("pet", bundle);

                                    startActivity(intent);
                                }
                            });
                        }

                        @Override
                        public void onFailure(int i, String s) {

                        }
                    });
                }
            }

            @Override
            public void onError(int i, String s) {

            }
        });
    }

    private void setWifeFamily(pet myPet) {
        BmobQuery<FamilyWife> wife = new BmobQuery<>();
        wife.addWhereEqualTo("petId", myPet.getObjectId());
        wife.findObjects(this, new FindListener<FamilyWife>() {
            @Override
            public void onSuccess(List<FamilyWife> list) {
                if (!list.isEmpty()) {
                    mFamilyWife = list.get(0);
                    BmobQuery<pet> petOb = new BmobQuery<>();
                    petOb.getObject(MyPetActivity.this, list.get(0).getWifeId(), new GetListener<course.leedev.cn.pubgassistant.model.pet>() {
                        @Override
                        public void onSuccess(final pet pet) {
                            Glide.with(MyPetActivity.this).load(pet.getAvatar()).into(mIvWifeAvatar);

                            mIvWifeAvatar.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent intent = new Intent(getContext(), PetActivity.class);
                                    Bundle bundle = new Bundle();
                                    bundle.putSerializable("pet", pet);
                                    intent.putExtra("pet", bundle);

                                    startActivity(intent);
                                }
                            });
                        }

                        @Override
                        public void onFailure(int i, String s) {

                        }
                    });
                }
            }

            @Override
            public void onError(int i, String s) {

            }
        });
    }

    private void setSonFamily(pet myPet) {
        BmobQuery<FamilySon> wife = new BmobQuery<>();
        wife.addWhereEqualTo("petId", myPet.getObjectId());
        wife.findObjects(this, new FindListener<FamilySon>() {
            @Override
            public void onSuccess(List<FamilySon> list) {
                if (!list.isEmpty()) {
                    mFamilySon = list.get(0);
                    BmobQuery<pet> petOb = new BmobQuery<>();
                    petOb.getObject(MyPetActivity.this, list.get(0).getSonId(), new GetListener<course.leedev.cn.pubgassistant.model.pet>() {
                        @Override
                        public void onSuccess(final pet pet) {
                            Glide.with(MyPetActivity.this).load(pet.getAvatar()).into(mIvSonAvatar);

                            mIvSonAvatar.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent intent = new Intent(getContext(), PetActivity.class);
                                    Bundle bundle = new Bundle();
                                    bundle.putSerializable("pet", pet);
                                    intent.putExtra("pet", bundle);

                                    startActivity(intent);
                                }
                            });
                        }

                        @Override
                        public void onFailure(int i, String s) {

                        }
                    });
                }
            }

            @Override
            public void onError(int i, String s) {

            }
        });
    }

    /**
     * 用户头像设置
     * @param pet
     */
    private void getUserInfo(pet pet) {
        BmobQuery<User> query = new BmobQuery<User>();
        query.getObject(this, pet.getUserid(), new GetListener<User>() {
            @Override
            public void onSuccess(User user) {
                Glide.with(MyPetActivity.this).load(user.getAvatar()).into(userAvatar);
                pet_user = user;

                userAvatar.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(GlobalApplication.getContext(), InfoActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("pet_user", pet_user);
                        intent.putExtra("pet_user", bundle);
                        startActivity(intent);
                    }
                });
            }

            @Override
            public void onFailure(int i, String s) {

            }
        });
    }

    @OnClick(R.id.pet_btn_add)
    public void btnAdd() {
        RxClipboardTool.copyText(MyPetActivity.this, mPet.getObjectId());
        RxToast.normal("已复制到剪切板");
    }

    /**
     * 添加关联关系
     */
    public void addLongClick() {
        //配偶设置
        wifeClick();
        //son设置
        sonClick();
        //daughter设置
        daughterClick();
    }

    private void daughterClick() {
        mIvDaughterAvatar.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                final RxDialogEditSureCancel rxDialogEditSureCancel = new RxDialogEditSureCancel(MyPetActivity.this);
                rxDialogEditSureCancel.setTitle("请输入宠物代码");
                rxDialogEditSureCancel.getEditText().setHint("输入delete删除关系...");
                rxDialogEditSureCancel.getCancelView().setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        rxDialogEditSureCancel.dismiss();
                    }
                });
                rxDialogEditSureCancel.getSureView().setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        final String code = rxDialogEditSureCancel.getEditText().getText().toString();
                        if (!RxDataTool.isNullString(code)) {
                            //删除操作
                            if (code.equals("delete")) {
                                if (mFamilyDdaughter == null) {
                                    RxToast.normal("daughter不存在");
                                } else {
                                    mFamilyDdaughter.delete(MyPetActivity.this, new DeleteListener() {
                                        @Override
                                        public void onSuccess() {
                                            mIvDaughterAvatar.setImageResource(R.mipmap.profile_picture);
                                            RxToast.normal("已删除");
                                        }

                                        @Override
                                        public void onFailure(int i, String s) {
                                            RxToast.normal(s);
                                        }
                                    });
                                }
                            } else {
                                BmobQuery<pet> searchPet = new BmobQuery<>();
                                searchPet.getObject(MyPetActivity.this, code, new GetListener<course.leedev.cn.pubgassistant.model.pet>() {
                                    @Override
                                    public void onSuccess(final pet pet) {
                                        final RxDialogSureCancel rxDialogSureCancel = new RxDialogSureCancel(MyPetActivity.this);
                                        rxDialogSureCancel.setTitle("确定添加为son吗？");
                                        rxDialogSureCancel.setContent("宠物昵称：" +  pet.getName());
                                        rxDialogSureCancel.getCancelView().setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                rxDialogSureCancel.dismiss();
                                            }
                                        });
                                        rxDialogSureCancel.getSureView().setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                FamilyDaughter wife = new FamilyDaughter();
                                                if (mFamilyDdaughter == null) {
                                                    wife.setPetId(mPet.getObjectId());
                                                    wife.setDaughterId(code);
                                                    wife.save(MyPetActivity.this, new SaveListener() {
                                                        @Override
                                                        public void onSuccess() {

                                                            Glide.with(MyPetActivity.this).load(pet.getAvatar()).into(mIvDaughterAvatar);

                                                            mIvDaughterAvatar.setOnClickListener(new View.OnClickListener() {
                                                                @Override
                                                                public void onClick(View view) {
                                                                    Intent intent = new Intent(getContext(), PetActivity.class);
                                                                    Bundle bundle = new Bundle();
                                                                    bundle.putSerializable("pet", pet);
                                                                    intent.putExtra("pet", bundle);

                                                                    startActivity(intent);
                                                                }
                                                            });

                                                            rxDialogSureCancel.dismiss();
                                                            RxToast.normal("添加成功");
                                                        }

                                                        @Override
                                                        public void onFailure(int i, String s) {
                                                            RxToast.normal(s);
                                                        }
                                                    });
                                                } else {
                                                    wife.setValue("daughterId", code);
                                                    wife.update(MyPetActivity.this, mFamilyDdaughter.getObjectId(), new UpdateListener() {
                                                        @Override
                                                        public void onSuccess() {

                                                            Glide.with(MyPetActivity.this).load(pet.getAvatar()).into(mIvDaughterAvatar);

                                                            mIvDaughterAvatar.setOnClickListener(new View.OnClickListener() {
                                                                @Override
                                                                public void onClick(View view) {
                                                                    Intent intent = new Intent(getContext(), PetActivity.class);
                                                                    Bundle bundle = new Bundle();
                                                                    bundle.putSerializable("pet", pet);
                                                                    intent.putExtra("pet", bundle);

                                                                    startActivity(intent);
                                                                }
                                                            });

                                                            rxDialogSureCancel.dismiss();
                                                            RxToast.normal("添加成功");
                                                        }

                                                        @Override
                                                        public void onFailure(int i, String s) {
                                                            RxToast.normal(s);
                                                        }
                                                    });
                                                }

                                            }
                                        });

                                        rxDialogSureCancel.show();
                                    }

                                    @Override
                                    public void onFailure(int i, String s) {
                                        RxToast.normal("找不到该宠物");
                                    }
                                });
                            }
                        } else {
                            RxToast.normal("宠物代码为空");
                        }

                        rxDialogEditSureCancel.dismiss();
                    }
                });

                rxDialogEditSureCancel.show();
                return true;
            }
        });
    }

    private void sonClick() {
        mIvSonAvatar.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                final RxDialogEditSureCancel rxDialogEditSureCancel = new RxDialogEditSureCancel(MyPetActivity.this);
                rxDialogEditSureCancel.setTitle("请输入宠物代码");
                rxDialogEditSureCancel.getEditText().setHint("输入delete删除关系...");
                rxDialogEditSureCancel.getCancelView().setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        rxDialogEditSureCancel.dismiss();
                    }
                });
                rxDialogEditSureCancel.getSureView().setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        final String code = rxDialogEditSureCancel.getEditText().getText().toString();
                        if (!RxDataTool.isNullString(code)) {
                            //删除操作
                            if (code.equals("delete")) {
                                if (mFamilySon == null) {
                                    RxToast.normal("son不存在");
                                } else {
                                    mFamilySon.delete(MyPetActivity.this, new DeleteListener() {
                                        @Override
                                        public void onSuccess() {
                                            mIvSonAvatar.setImageResource(R.mipmap.profile_picture);
                                            RxToast.normal("已删除");
                                        }

                                        @Override
                                        public void onFailure(int i, String s) {
                                            RxToast.normal(s);
                                        }
                                    });
                                }
                            } else {
                                BmobQuery<pet> searchPet = new BmobQuery<>();
                                searchPet.getObject(MyPetActivity.this, code, new GetListener<course.leedev.cn.pubgassistant.model.pet>() {
                                    @Override
                                    public void onSuccess(final pet pet) {
                                        final RxDialogSureCancel rxDialogSureCancel = new RxDialogSureCancel(MyPetActivity.this);
                                        rxDialogSureCancel.setTitle("确定添加为son吗？");
                                        rxDialogSureCancel.setContent("宠物昵称：" +  pet.getName());
                                        rxDialogSureCancel.getCancelView().setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                rxDialogSureCancel.dismiss();
                                            }
                                        });
                                        rxDialogSureCancel.getSureView().setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                FamilySon wife = new FamilySon();
                                                if (mFamilySon == null) {
                                                    wife.setPetId(mPet.getObjectId());
                                                    wife.setSonId(code);
                                                    wife.save(MyPetActivity.this, new SaveListener() {
                                                        @Override
                                                        public void onSuccess() {

                                                            Glide.with(MyPetActivity.this).load(pet.getAvatar()).into(mIvSonAvatar);

                                                            mIvSonAvatar.setOnClickListener(new View.OnClickListener() {
                                                                @Override
                                                                public void onClick(View view) {
                                                                    Intent intent = new Intent(getContext(), PetActivity.class);
                                                                    Bundle bundle = new Bundle();
                                                                    bundle.putSerializable("pet", pet);
                                                                    intent.putExtra("pet", bundle);

                                                                    startActivity(intent);
                                                                }
                                                            });

                                                            rxDialogSureCancel.dismiss();
                                                            RxToast.normal("添加成功");
                                                        }

                                                        @Override
                                                        public void onFailure(int i, String s) {
                                                            RxToast.normal(s);
                                                        }
                                                    });
                                                } else {
                                                    wife.setValue("sonId", code);
                                                    wife.update(MyPetActivity.this, mFamilySon.getObjectId(), new UpdateListener() {
                                                        @Override
                                                        public void onSuccess() {

                                                            Glide.with(MyPetActivity.this).load(pet.getAvatar()).into(mIvSonAvatar);

                                                            mIvSonAvatar.setOnClickListener(new View.OnClickListener() {
                                                                @Override
                                                                public void onClick(View view) {
                                                                    Intent intent = new Intent(getContext(), PetActivity.class);
                                                                    Bundle bundle = new Bundle();
                                                                    bundle.putSerializable("pet", pet);
                                                                    intent.putExtra("pet", bundle);

                                                                    startActivity(intent);
                                                                }
                                                            });

                                                            rxDialogSureCancel.dismiss();
                                                            RxToast.normal("添加成功");
                                                        }

                                                        @Override
                                                        public void onFailure(int i, String s) {
                                                            RxToast.normal(s);
                                                        }
                                                    });
                                                }

                                            }
                                        });

                                        rxDialogSureCancel.show();
                                    }

                                    @Override
                                    public void onFailure(int i, String s) {
                                        RxToast.normal("找不到该宠物");
                                    }
                                });
                            }
                        } else {
                            RxToast.normal("宠物代码为空");
                        }

                        rxDialogEditSureCancel.dismiss();
                    }
                });

                rxDialogEditSureCancel.show();
                return true;
            }
        });
    }

    private void wifeClick() {

        mIvWifeAvatar.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                final RxDialogEditSureCancel rxDialogEditSureCancel = new RxDialogEditSureCancel(MyPetActivity.this);
                rxDialogEditSureCancel.setTitle("请输入宠物代码");
                rxDialogEditSureCancel.getEditText().setHint("输入delete删除关系...");
                rxDialogEditSureCancel.getCancelView().setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        rxDialogEditSureCancel.dismiss();
                    }
                });
                rxDialogEditSureCancel.getSureView().setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        final String code = rxDialogEditSureCancel.getEditText().getText().toString();
                        if (!RxDataTool.isNullString(code)) {
                            //删除操作
                            if (code.equals("delete")) {
                                if (mFamilyWife == null) {
                                    RxToast.normal("配偶不存在");
                                } else {
                                    mFamilyWife.delete(MyPetActivity.this, new DeleteListener() {
                                        @Override
                                        public void onSuccess() {
                                            mIvWifeAvatar.setImageResource(R.mipmap.profile_picture);
                                            RxToast.normal("已删除");
                                        }

                                        @Override
                                        public void onFailure(int i, String s) {
                                            RxToast.normal(s);
                                        }
                                    });
                                }
                            } else {
                                BmobQuery<pet> searchPet = new BmobQuery<>();
                                searchPet.getObject(MyPetActivity.this, code, new GetListener<course.leedev.cn.pubgassistant.model.pet>() {
                                    @Override
                                    public void onSuccess(final pet pet) {
                                        final RxDialogSureCancel rxDialogSureCancel = new RxDialogSureCancel(MyPetActivity.this);
                                        rxDialogSureCancel.setTitle("确定添加为配偶吗？");
                                        rxDialogSureCancel.setContent("宠物昵称：" +  pet.getName());
                                        rxDialogSureCancel.getCancelView().setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                rxDialogSureCancel.dismiss();
                                            }
                                        });
                                        rxDialogSureCancel.getSureView().setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                FamilyWife wife = new FamilyWife();
                                                if (mFamilyWife == null) {
                                                    wife.setPetId(mPet.getObjectId());
                                                    wife.setWifeId(code);
                                                    wife.save(MyPetActivity.this, new SaveListener() {
                                                        @Override
                                                        public void onSuccess() {

                                                            Glide.with(MyPetActivity.this).load(pet.getAvatar()).into(mIvWifeAvatar);

                                                            mIvWifeAvatar.setOnClickListener(new View.OnClickListener() {
                                                                @Override
                                                                public void onClick(View view) {
                                                                    Intent intent = new Intent(getContext(), PetActivity.class);
                                                                    Bundle bundle = new Bundle();
                                                                    bundle.putSerializable("pet", pet);
                                                                    intent.putExtra("pet", bundle);

                                                                    startActivity(intent);
                                                                }
                                                            });

                                                            rxDialogSureCancel.dismiss();
                                                            RxToast.normal("添加成功");
                                                        }

                                                        @Override
                                                        public void onFailure(int i, String s) {
                                                            RxToast.normal(s);
                                                        }
                                                    });
                                                } else {
                                                    wife.setValue("wifeId", code);
                                                    wife.update(MyPetActivity.this, mFamilyWife.getObjectId(), new UpdateListener() {
                                                        @Override
                                                        public void onSuccess() {

                                                            Glide.with(MyPetActivity.this).load(pet.getAvatar()).into(mIvWifeAvatar);

                                                            mIvWifeAvatar.setOnClickListener(new View.OnClickListener() {
                                                                @Override
                                                                public void onClick(View view) {
                                                                    Intent intent = new Intent(getContext(), PetActivity.class);
                                                                    Bundle bundle = new Bundle();
                                                                    bundle.putSerializable("pet", pet);
                                                                    intent.putExtra("pet", bundle);

                                                                    startActivity(intent);
                                                                }
                                                            });

                                                            rxDialogSureCancel.dismiss();
                                                            RxToast.normal("添加成功");
                                                        }

                                                        @Override
                                                        public void onFailure(int i, String s) {
                                                            RxToast.normal(s);
                                                        }
                                                    });
                                                }

                                            }
                                        });

                                        rxDialogSureCancel.show();
                                    }

                                    @Override
                                    public void onFailure(int i, String s) {
                                        RxToast.normal("找不到该宠物");
                                    }
                                });
                            }
                        } else {
                            RxToast.normal("宠物代码为空");
                        }

                        rxDialogEditSureCancel.dismiss();
                    }
                });

                rxDialogEditSureCancel.show();
                return true;
            }
        });
    }
}
