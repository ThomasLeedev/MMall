package course.leedev.cn.pubgassistant.model.family;

import cn.bmob.v3.BmobObject;

public class FamilyWife extends BmobObject {

    String petId;
    String wifeId;

    public String getPetId() {
        return petId;
    }

    public void setPetId(String petId) {
        this.petId = petId;
    }

    public String getWifeId() {
        return wifeId;
    }

    public void setWifeId(String wifeId) {
        this.wifeId = wifeId;
    }
}
