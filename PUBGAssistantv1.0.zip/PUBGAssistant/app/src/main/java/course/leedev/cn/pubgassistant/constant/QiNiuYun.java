package course.leedev.cn.pubgassistant.constant;

import com.qiniu.android.storage.UploadManager;

/**
 * Created by lt on 18-5-28.
 */

public class QiNiuYun {

    private static UploadManager uploadManager;

//    public static final  KEY =

    public static UploadManager getUploadManager() {
        if (uploadManager == null) {
            uploadManager = new UploadManager();
        }
        return uploadManager;
    }


}
