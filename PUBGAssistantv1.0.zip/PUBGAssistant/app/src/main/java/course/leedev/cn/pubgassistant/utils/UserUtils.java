package course.leedev.cn.pubgassistant.utils;

import course.leedev.cn.pubgassistant.model.User;

public class UserUtils {

    private static User user;

    public static User getUser() {
        if (user == null) {
            user = (User) User.getCurrentUser(AppUtils.getContext(), User.class);
        }
        return user;
    }

}
