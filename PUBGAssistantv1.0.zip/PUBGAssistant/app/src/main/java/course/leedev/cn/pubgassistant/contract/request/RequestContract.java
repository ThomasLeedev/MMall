package course.leedev.cn.pubgassistant.contract.request;

import course.leedev.cn.pubgassistant.base.BasePresenter;
import course.leedev.cn.pubgassistant.base.IBaseFragment;
import course.leedev.cn.pubgassistant.base.IBaseModel;

/**
 * Created by lt on 2017/12/30.
 *
 * 请求主页 Contract
 */

public interface RequestContract {

    // 主页接口
    abstract class RequestPresenter extends BasePresenter<IRequestModel, IRequestView> {
        public abstract void getTabList();
    }

    interface IRequestModel extends IBaseModel {
        String[] getTabs();
    }

    interface IRequestView extends IBaseFragment {
        void showTabList(String[] tabs);
    }
}
