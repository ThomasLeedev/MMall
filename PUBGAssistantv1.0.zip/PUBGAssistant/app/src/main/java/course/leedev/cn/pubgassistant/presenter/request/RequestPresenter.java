package course.leedev.cn.pubgassistant.presenter.request;

import android.support.annotation.NonNull;

import course.leedev.cn.pubgassistant.contract.home.HomeMainContract;
import course.leedev.cn.pubgassistant.contract.request.RequestContract;
import course.leedev.cn.pubgassistant.model.home.HomeMainModel;
import course.leedev.cn.pubgassistant.model.request.RequestModel;

/**
 * Created by lt on 2017/12/31.
 */

public class RequestPresenter extends RequestContract.RequestPresenter {

    @NonNull
    public static RequestPresenter newInstance() {
        return new RequestPresenter();
    }

    @Override
    public void getTabList() {
        if (mIView == null || mIModel == null) {
            return;
        }
        mIView.showTabList(mIModel.getTabs());
    }

    @Override
    public RequestContract.IRequestModel getModel() {
        return RequestModel.newInstance();
    }

    @Override
    protected void onStart() {

    }
}
