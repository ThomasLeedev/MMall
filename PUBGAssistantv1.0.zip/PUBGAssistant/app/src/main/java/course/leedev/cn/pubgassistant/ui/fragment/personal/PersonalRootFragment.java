package course.leedev.cn.pubgassistant.ui.fragment.personal;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import butterknife.BindView;
import cn.bmob.v3.BmobUser;
import course.leedev.cn.pubgassistant.R;
import course.leedev.cn.pubgassistant.base.fragment.BaseCompatFragment;
import course.leedev.cn.pubgassistant.model.User;
import course.leedev.cn.pubgassistant.ui.fragment.news.NewsRootFragment;
import course.leedev.cn.pubgassistant.ui.fragment.news.child.RequestFragment;
import course.leedev.cn.pubgassistant.ui.fragment.personal.child.PersonalFragment;
import retrofit2.http.POST;

/**
 * Created by thoma on 2018/1/9.
 */

public class PersonalRootFragment extends BaseCompatFragment {


    private SharedPreferences sharedPreferences;

    public static PersonalRootFragment newInstance() {
        Bundle args = new Bundle();
        PersonalRootFragment fragment = new PersonalRootFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    protected void initUI(View view, Bundle savedInstanceState) {
        if (findChildFragment(PersonalFragment.class) == null) {
            loadRootFragment(R.id.person_fl_container, PersonalFragment.newInstance());
        }
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_personal;
    }
}
