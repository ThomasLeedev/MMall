package course.leedev.cn.pubgassistant.ui.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.PersistableBundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.vansuita.materialabout.builder.AboutBuilder;
import com.vansuita.materialabout.views.AboutView;
import com.vondear.rxtools.RxClipboardTool;
import com.vondear.rxtools.view.RxQRCode;
import com.vondear.rxtools.view.RxToast;
import com.vondear.rxtools.view.dialog.RxDialog;
import com.vondear.rxtools.view.dialog.RxDialogSure;
import com.vondear.rxtools.view.dialog.RxDialogSureCancel;
import com.vondear.rxtools.view.dialog.RxDialogTool;
import com.vondear.rxtools.view.dialog.RxDialogWheelYearMonthDay;
import com.vondear.rxtools.view.popupwindows.tools.RxPopupView;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;

import butterknife.BindView;
import butterknife.OnClick;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.datatype.BmobFile;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.GetListener;
import cn.bmob.v3.listener.UploadFileListener;
import course.leedev.cn.pubgassistant.R;
import course.leedev.cn.pubgassistant.base.activity.BaseActivity;
import course.leedev.cn.pubgassistant.global.GlobalApplication;
import course.leedev.cn.pubgassistant.model.User;
import course.leedev.cn.pubgassistant.model.family.FamilyDaughter;
import course.leedev.cn.pubgassistant.model.family.FamilySon;
import course.leedev.cn.pubgassistant.model.family.FamilyWife;
import course.leedev.cn.pubgassistant.model.pet;
import course.leedev.cn.pubgassistant.utils.AgeUtils;
import de.hdodenhof.circleimageview.CircleImageView;

import static course.leedev.cn.pubgassistant.utils.AppUtils.getContext;

/**
 * Created by lt on 18-6-17.
 */

public class PetActivity extends BaseActivity {

    @BindView(R.id.pet_iv_avatar)
    CircleImageView avatar;
    @BindView(R.id.pet_tv_age)
    TextView age;
    @BindView(R.id.pet_tv_category)
    TextView category;
    @BindView(R.id.pet_tv_name)
    TextView name;
    @BindView(R.id.pet_iv_user_avatar)
    CircleImageView userAvatar;
    @BindView(R.id.pet_ll_host)
    LinearLayout petHost;
    @BindView(R.id.pet_iv_qrcode)
    ImageView petQrCode;

    @BindView(R.id.pet_iv_wife_avatar)
    CircleImageView mIvWifeAvatar;
    @BindView(R.id.pet_iv_son_avatar)
    CircleImageView mIvSonAvatar;
    @BindView(R.id.pet_iv_daughter_avatar)
    CircleImageView mIvDaughterAvatar;

    private FamilyWife mFamilyWife;
    private FamilySon mFamilySon;
    private FamilyDaughter mFamilyDdaughter;

    private User pet_user;
    pet pet;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_pet;
    }

    @Override
    protected void initView(Bundle savedInstanceState) {

        final Intent intent = getIntent();
        final Bundle bundle = intent.getBundleExtra("pet");
        pet = (course.leedev.cn.pubgassistant.model.pet) bundle.getSerializable("pet");

        Glide.with(this).load(pet.getAvatar()).into(avatar);

        name.setText(pet.getName());
        category.setText(pet.getCategory());

        if (pet.getGender().equals("雄性")) {
            age.setText("♂ " + AgeUtils.getAgeFromBirthTime(pet.getBirthday()));
            age.setBackground(getResources().getDrawable(R.drawable.shape_gender));
        } else {
            age.setText("♀ " + AgeUtils.getAgeFromBirthTime(pet.getBirthday()));
        }

        RxQRCode.createQRCode(pet.getObjectId(), petQrCode);

        petQrCode.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                final RxDialogSure rxDialog = new RxDialogSure(PetActivity.this);
                rxDialog.setTitle("保存图片到相册");
                rxDialog.setContent("");
                rxDialog.setSure("保存");
                rxDialog.setSureListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //图片保存
                        MediaStore.Images.Media.insertImage(getContentResolver(), RxQRCode.creatQRCode(pet.getObjectId(), 400, 400), pet.getName()+".jpg", "qrcode");
                        sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(new File("/sdcard/Boohee/image.jpg"))));



                        rxDialog.dismiss();
                        RxToast.normal("保存成功");
                    }
                });
                rxDialog.show();
                return false;
            }
        });
//        BmobQuery<User> query = new BmobQuery<User>();
//        query.getObject(getContext(), pet.getUserid(), new GetListener<User>() {
//            @Override
//            public void onSuccess(final User user) {
//
//                Glide.with(getContext()).load(user.getAvatar()).into(userAvatar);
//                petHost.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        Intent intent1 = new Intent(getContext(), UserActivity.class);
//                        Bundle bundle1 = new Bundle();
//                        bundle1.putSerializable("user", user);
//                        intent1.putExtra("user", bundle1);
//                        startActivity(intent1);
//                    }
//                });
//            }
//
//            @Override
//            public void onFailure(int i, String s) {
//                RxToast.normal("出现问题！请稍后重试！");
//            }
//        });

        getUserInfo(pet);

        setWifeFamily(pet);
        setDaughterFamily(pet);
        setSonFamily(pet);
    }

    private void getUserInfo(pet pet) {
        BmobQuery<User> query = new BmobQuery<User>();
        query.getObject(this, pet.getUserid(), new GetListener<User>() {
            @Override
            public void onSuccess(User user) {
                Glide.with(PetActivity.this).load(user.getAvatar()).into(userAvatar);
                pet_user = user;

                userAvatar.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(GlobalApplication.getContext(), InfoActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("pet_user", pet_user);
                        intent.putExtra("pet_user", bundle);
                        startActivity(intent);
                    }
                });
            }

            @Override
            public void onFailure(int i, String s) {

            }
        });
    }

    public void uploadImg(File file) {
        BmobFile bmobFile = new BmobFile(file);
        bmobFile.uploadblock(this, new UploadFileListener() {
            @Override
            public void onSuccess() {
                Log.d("AvatarUpLoad", "onSuccess: ");
            }

            @Override
            public void onFailure(int i, String s) {
                Log.d("AvatarUpLoad", "onFailure: ");
            }
        });
    }

    @OnClick(R.id.pet_btn_add)
    public void btnAdd() {
        RxClipboardTool.copyText(PetActivity.this, pet.getObjectId());
        RxToast.normal("已复制到剪切板");
    }

    /**
     * 关联关系设置Wife, Son, Daughter
     * @param myPet
     */
    private void setDaughterFamily(pet myPet) {
        BmobQuery<FamilyDaughter> wife = new BmobQuery<>();
        wife.addWhereEqualTo("petId", myPet.getObjectId());
        wife.findObjects(this, new FindListener<FamilyDaughter>() {
            @Override
            public void onSuccess(List<FamilyDaughter> list) {
                if (!list.isEmpty()) {
                    mFamilyDdaughter = list.get(0);
                    BmobQuery<pet> petOb = new BmobQuery<>();
                    petOb.getObject(PetActivity.this, list.get(0).getDaughterId(), new GetListener<course.leedev.cn.pubgassistant.model.pet>() {
                        @Override
                        public void onSuccess(final pet pet) {
                            Glide.with(PetActivity.this).load(pet.getAvatar()).into(mIvDaughterAvatar);

                            mIvDaughterAvatar.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent intent = new Intent(GlobalApplication.getContext(), PetActivity.class);
                                    Bundle bundle = new Bundle();
                                    bundle.putSerializable("pet", pet);
                                    intent.putExtra("pet", bundle);

                                    startActivity(intent);
                                }
                            });
                        }

                        @Override
                        public void onFailure(int i, String s) {

                        }
                    });
                }
            }

            @Override
            public void onError(int i, String s) {

            }
        });
    }

    private void setWifeFamily(pet myPet) {
        BmobQuery<FamilyWife> wife = new BmobQuery<>();
        wife.addWhereEqualTo("petId", myPet.getObjectId());
        wife.findObjects(this, new FindListener<FamilyWife>() {
            @Override
            public void onSuccess(List<FamilyWife> list) {
                if (!list.isEmpty()) {
                    mFamilyWife = list.get(0);
                    BmobQuery<pet> petOb = new BmobQuery<>();
                    petOb.getObject(PetActivity.this, list.get(0).getWifeId(), new GetListener<course.leedev.cn.pubgassistant.model.pet>() {
                        @Override
                        public void onSuccess(final pet pet) {
                            Glide.with(PetActivity.this).load(pet.getAvatar()).into(mIvWifeAvatar);

                            mIvWifeAvatar.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent intent = new Intent(GlobalApplication.getContext(), PetActivity.class);
                                    Bundle bundle = new Bundle();
                                    bundle.putSerializable("pet", pet);
                                    intent.putExtra("pet", bundle);

                                    startActivity(intent);
                                }
                            });
                        }

                        @Override
                        public void onFailure(int i, String s) {

                        }
                    });
                }
            }

            @Override
            public void onError(int i, String s) {

            }
        });
    }

    private void setSonFamily(pet myPet) {
        BmobQuery<FamilySon> wife = new BmobQuery<>();
        wife.addWhereEqualTo("petId", myPet.getObjectId());
        wife.findObjects(this, new FindListener<FamilySon>() {
            @Override
            public void onSuccess(List<FamilySon> list) {
                if (!list.isEmpty()) {
                    mFamilySon = list.get(0);
                    BmobQuery<pet> petOb = new BmobQuery<>();
                    petOb.getObject(PetActivity.this, list.get(0).getSonId(), new GetListener<course.leedev.cn.pubgassistant.model.pet>() {
                        @Override
                        public void onSuccess(final pet pet) {
                            Glide.with(PetActivity.this).load(pet.getAvatar()).into(mIvSonAvatar);

                            mIvSonAvatar.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent intent = new Intent(GlobalApplication.getContext(), PetActivity.class);
                                    Bundle bundle = new Bundle();
                                    bundle.putSerializable("pet", pet);
                                    intent.putExtra("pet", bundle);

                                    startActivity(intent);
                                }
                            });
                        }

                        @Override
                        public void onFailure(int i, String s) {

                        }
                    });
                }
            }

            @Override
            public void onError(int i, String s) {

            }
        });
    }

}
