package course.leedev.cn.pubgassistant.ui.activity;

import android.app.ActionBar;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.widget.LinearLayout;

import com.just.agentweb.AgentWeb;

import butterknife.BindView;
import course.leedev.cn.pubgassistant.R;
import course.leedev.cn.pubgassistant.base.activity.BaseActivity;

/**
 * Created by lt on 18-6-2.
 */

public class VideoActivity extends BaseActivity {

    @BindView(R.id.video_ll)
    LinearLayout ll;
//    @BindView(R.id.video_tool_bar)
//    Toolbar tb;

    private AgentWeb agentWeb;
    private Intent intent;

    public static final String VideoTitle = "video_title";
    public static final String VideoLink = "video_link";

    @Override
    protected int getLayoutId() {
        return R.layout.activity_video;
    }


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void initView(Bundle savedInstanceState) {

        intent = getIntent();

//        setSupportActionBar(tb);
//        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
//        if (actionBar != null) {
//            actionBar.setDisplayHomeAsUpEnabled(true);
//        }

        String title = intent.getStringExtra(VideoTitle);
        String link = intent.getStringExtra(VideoLink);

//        tb.setTitle(title);

        Log.d("VideoActivity", "initView: " + link);

        agentWeb = AgentWeb.with(this)
                .setAgentWebParent((LinearLayout) ll, new LinearLayout.LayoutParams(-1, -1))
                .useDefaultIndicator()
                .createAgentWeb()
                .ready()
                .go(link);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (agentWeb != null) {
            agentWeb.destroy();
        }
    }
}
