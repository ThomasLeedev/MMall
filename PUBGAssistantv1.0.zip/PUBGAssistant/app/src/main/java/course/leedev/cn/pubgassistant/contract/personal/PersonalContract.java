package course.leedev.cn.pubgassistant.contract.personal;

import course.leedev.cn.pubgassistant.base.BasePresenter;
import course.leedev.cn.pubgassistant.base.IBaseFragment;
import course.leedev.cn.pubgassistant.base.IBaseModel;

/**
 * Created by lt on 2017/12/30.
 *
 * 助手主页 Contract
 */

public interface PersonalContract {

    // 主页接口
    abstract class PersonalPresenter extends BasePresenter<IPersonalModel, IPersonalView> {
        public abstract void getTabList();
    }

    interface IPersonalModel extends IBaseModel {
        String[] getTabs();
    }

    interface IPersonalView extends IBaseFragment {
        void showTabList(String[] tabs);
    }
}
