package course.leedev.cn.pubgassistant.ui.fragment.personal.child.tabs;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.vondear.rxtools.view.RxToast;
import com.vondear.rxtools.view.dialog.RxDialogSureCancel;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.listener.DeleteListener;
import cn.bmob.v3.listener.FindListener;
import course.leedev.cn.pubgassistant.R;
import course.leedev.cn.pubgassistant.base.fragment.BaseCompatFragment;
import course.leedev.cn.pubgassistant.model.User;
import course.leedev.cn.pubgassistant.model.home.tabs.Article;
import course.leedev.cn.pubgassistant.model.pet;
import course.leedev.cn.pubgassistant.ui.activity.MyPetActivity;
import course.leedev.cn.pubgassistant.ui.activity.PetActivity;
import course.leedev.cn.pubgassistant.ui.activity.VideoActivity;

import static course.leedev.cn.pubgassistant.global.GlobalApplication.getContext;

/**
 * 文章页面
 *
 * Created by lt on 2018/1/8.
 */

public class PetsFragment extends BaseCompatFragment {

    @BindView(R.id.pets_rv)
    RecyclerView recyclerView;

    @BindView(R.id.article_refresh)
    SmartRefreshLayout smartRefreshLayout;

    private List<Article> list = new ArrayList<>();
    private BmobUser user;

    public static PetsFragment newInstance() {
        return new PetsFragment();
    }

    @Override
    protected void initUI(View view, Bundle savedInstanceState) {

        initRefresh();
        initModel();

    }

    private void initRefresh() {
        smartRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                initModel(refreshLayout);
            }
        });

        smartRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                refreshLayout.finishLoadMore(3000);
            }
        });
    }

    private void initModel(final RefreshLayout refreshLayout) {
        user = User.getCurrentUser(getContext());

        BmobQuery<pet> query = new BmobQuery<>();
        query.addWhereEqualTo("userid", user.getObjectId());
        query.findObjects(getContext(), new FindListener<pet>() {
            @Override
            public void onSuccess(List<pet> list) {
                HomeAdapter adapter = new HomeAdapter(R.layout.item_fragment_home_register, list);
                adapter.openLoadAnimation();

                adapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
//                        Intent intent = new Intent(getContext(), VideoActivity.class);
//                        intent.putExtra(VideoActivity.VideoTitle, ((Article) adapter.getItem(position)).getTitle());
//                        intent.putExtra(VideoActivity.VideoLink, ((Article) adapter.getItem(position)).getLink());
//                        startActivity(intent);
                        Intent intent = new Intent(getContext(), MyPetActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("pet", (pet) adapter.getItem(position));
                        intent.putExtra("pet", bundle);

                        startActivity(intent);
                    }
                });

                adapter.setOnItemLongClickListener(new BaseQuickAdapter.OnItemLongClickListener() {
                    @Override
                    public boolean onItemLongClick(BaseQuickAdapter adapter, View view, int position) {
                        final pet mypet = (pet) adapter.getItem(position);
                        final RxDialogSureCancel rxDialogSureCancel = new RxDialogSureCancel(getActivity());
                        rxDialogSureCancel.setTitle("确认删除" + mypet.getName() + "吗？");
                        rxDialogSureCancel.getCancelView().setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                rxDialogSureCancel.dismiss();
                            }
                        });
                        rxDialogSureCancel.getSureView().setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                mypet.delete(getActivity(), new DeleteListener() {
                                    @Override
                                    public void onSuccess() {
                                        RxToast.normal("删除成功");
                                        rxDialogSureCancel.dismiss();
                                        smartRefreshLayout.autoRefresh();
                                    }

                                    @Override
                                    public void onFailure(int i, String s) {

                                    }
                                });
                            }
                        });
                        rxDialogSureCancel.show();
                        return false;
                    }
                });

                recyclerView.setAdapter(adapter);
                recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

                refreshLayout.finishRefresh(2000);

            }

            @Override
            public void onError(int i, String s) {
                Log.i("bmob","失败："+s);
                refreshLayout.finishRefresh(2000, false);
            }
        });
    }

    private void initModel() {
        user = User.getCurrentUser(getContext());

        BmobQuery<pet> query = new BmobQuery<>();
        query.addWhereEqualTo("userid", user.getObjectId());
        query.findObjects(getContext(), new FindListener<pet>() {
            @Override
            public void onSuccess(List<pet> list) {
                HomeAdapter adapter = new HomeAdapter(R.layout.item_fragment_home_register, list);
                adapter.openLoadAnimation();

                adapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
//                        Intent intent = new Intent(getContext(), VideoActivity.class);
//                        intent.putExtra(VideoActivity.VideoTitle, ((Article) adapter.getItem(position)).getTitle());
//                        intent.putExtra(VideoActivity.VideoLink, ((Article) adapter.getItem(position)).getLink());
//                        startActivity(intent);

                        Intent intent = new Intent(getContext(), MyPetActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("pet", (pet) adapter.getItem(position));
                        intent.putExtra("pet", bundle);

                        startActivity(intent);
                    }
                });

                adapter.setOnItemLongClickListener(new BaseQuickAdapter.OnItemLongClickListener() {
                    @Override
                    public boolean onItemLongClick(BaseQuickAdapter adapter, View view, int position) {
                        final pet mypet = (pet) adapter.getItem(position);
                        final RxDialogSureCancel rxDialogSureCancel = new RxDialogSureCancel(getActivity());
                        rxDialogSureCancel.setTitle("确认删除" + mypet.getName() + "吗？");
                        rxDialogSureCancel.getCancelView().setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                rxDialogSureCancel.dismiss();
                            }
                        });
                        rxDialogSureCancel.getSureView().setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                mypet.delete(getActivity(), new DeleteListener() {
                                    @Override
                                    public void onSuccess() {
                                        RxToast.normal("删除成功");
                                        rxDialogSureCancel.dismiss();
                                        smartRefreshLayout.autoRefresh();
                                    }

                                    @Override
                                    public void onFailure(int i, String s) {

                                    }
                                });
                            }
                        });
                        rxDialogSureCancel.show();
                        return false;
                    }
                });

                recyclerView.setAdapter(adapter);
                recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

                System.out.println("hello");

            }

            @Override
            public void onError(int i, String s) {
                Log.i("bmob","失败："+s);
            }
        });
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_personal_pets;
    }

    public class HomeAdapter extends BaseQuickAdapter<pet, BaseViewHolder> {
        public HomeAdapter(int layoutResId, List data) {
            super(layoutResId, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, pet item) {
            Glide.with(getActivity()).load(item.getAvatar()).into((ImageView) helper.getView(R.id.article_iv_cover));
            helper.setText(R.id.article_tv_title, item.getName());
            helper.setText(R.id.article_tv_data, item.getCreatedAt());
            helper.setText(R.id.article_tv_summary, item.getCategory());
//            Glide.with(mContext).load(item.getUserAvatar()).crossFade().into((ImageView) helper.getView(R.id.iv));
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        smartRefreshLayout.autoRefresh();
    }
}
