package course.leedev.cn.pubgassistant.model.family;

import cn.bmob.v3.BmobObject;

public class FamilyDaughter extends BmobObject {

    String petId;
    String daughterId;

    public String getPetId() {
        return petId;
    }

    public void setPetId(String petId) {
        this.petId = petId;
    }

    public String getDaughterId() {
        return daughterId;
    }

    public void setDaughterId(String daughterId) {
        this.daughterId = daughterId;
    }
}
