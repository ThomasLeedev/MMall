package course.leedev.cn.pubgassistant.ui.fragment.home.child.tabs;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.jakewharton.rxbinding2.view.RxView;
import com.just.agentweb.AgentWeb;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.vondear.rxtools.RxWebViewTool;
import com.vondear.rxtools.activity.ActivityWebView;
import com.vondear.rxtools.view.RxToast;

import org.reactivestreams.Subscription;
import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;
import course.leedev.cn.pubgassistant.R;
import course.leedev.cn.pubgassistant.base.BasePresenter;
import course.leedev.cn.pubgassistant.base.fragment.BaseCompatFragment;
import course.leedev.cn.pubgassistant.contract.home.tabs.RequestQRCodeContract;
import course.leedev.cn.pubgassistant.helper.RxHelper;
import course.leedev.cn.pubgassistant.model.home.tabs.Article;
import course.leedev.cn.pubgassistant.model.home.tabs.Video;
import course.leedev.cn.pubgassistant.presenter.home.tabs.RequestQRCodePresenter;
import course.leedev.cn.pubgassistant.service.MyService;
import course.leedev.cn.pubgassistant.ui.activity.VideoActivity;
import io.reactivex.Observable;
import io.reactivex.ObservableSource;
import io.reactivex.Observer;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.functions.Predicate;
import io.reactivex.schedulers.Schedulers;
import me.yokeyword.fragmentation.SupportFragment;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

/**
 * 录播页面
 *
 * Created by lgx on 2018/1/7.
 */

public class RequestQRCodeFragment extends BaseCompatFragment<RequestQRCodeContract.RequestQRCodePresenter,
        RequestQRCodeContract.IRequestQRCodeModel> implements RequestQRCodeContract.IRequestQRCodeView {

    @BindView(R.id.recording_rv)
    RecyclerView recyclerView;
    @BindView(R.id.video_refresh)
    SmartRefreshLayout smartRefreshLayout;

    private boolean isInited = false;

//    private List<Recoding> mylist = new ArrayList<>();

    public static RequestQRCodeFragment newInstance() {
        Bundle args = new Bundle();
        RequestQRCodeFragment requestQRCodeFragment = new RequestQRCodeFragment();
        requestQRCodeFragment.setArguments(args);
        return requestQRCodeFragment;
    }

    @Override
    protected void initUI(View view, Bundle savedInstanceState) {
        initRefresh();
    }

    private void initRefresh() {
        smartRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                initModel(refreshLayout);
            }
        });

        smartRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                refreshLayout.finishLoadMore(3000);
            }
        });
    }

    private void initModel(final RefreshLayout refreshLayout) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                BmobQuery<Video> query = new BmobQuery<>();

                query.findObjects(getContext(), new FindListener<Video>() {
                    @Override
                    public void onSuccess(List<Video> list) {
                        final HomeAdapter adapter = new HomeAdapter(R.layout.item_fragment_home_recording, list);
                        adapter.openLoadAnimation();

                        adapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
                            @Override
                            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                                Intent intent = new Intent(getContext(), VideoActivity.class);
                                intent.putExtra(VideoActivity.VideoTitle, ((Video) adapter.getItem(position)).getTitle());
                                intent.putExtra(VideoActivity.VideoTitle, ((Video) adapter.getItem(position)).getLink());
                                startActivity(intent);
                            }
                        });

                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                recyclerView.setAdapter(adapter);
                                recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

                                refreshLayout.finishRefresh(2000);
                            }
                        });

                    }

                    @Override
                    public void onError(int i, String s) {
                        Log.i("bmob","失败："+s);
                        refreshLayout.finishRefresh(2000, false);
                    }
                });
            }
        }).start();
    }

    private void initModel() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                BmobQuery<Video> query = new BmobQuery<>();

                query.findObjects(getContext(), new FindListener<Video>() {
                    @Override
                    public void onSuccess(List<Video> list) {
                        final HomeAdapter adapter = new HomeAdapter(R.layout.item_fragment_home_recording, list);
                        adapter.openLoadAnimation();

                        adapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
                            @Override
                            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                                Intent intent = new Intent(getContext(), VideoActivity.class);
                                intent.putExtra(VideoActivity.VideoTitle, ((Video) adapter.getItem(position)).getTitle());
                                intent.putExtra(VideoActivity.VideoLink, ((Video) adapter.getItem(position)).getLink());
                                startActivity(intent);
                            }
                        });

                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                recyclerView.setAdapter(adapter);
                                recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                            }
                        });

                    }

                    @Override
                    public void onError(int i, String s) {
                        Log.i("bmob","失败："+s);
                    }
                });
            }
        }).start();
    }

    public class HomeAdapter extends BaseQuickAdapter<Video, BaseViewHolder> {
        public HomeAdapter(int layoutResId, List data) {
            super(layoutResId, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, Video item) {
            helper.setText(R.id.recoding_tv_title, item.getTitle());
//            helper.setImageResource(R.id.recoding_iv_cover, R.drawable.img_avatar_01);
            helper.setText(R.id.recoding_tv_name, item.getAuthor());
            helper.setText(R.id.recoding_tv_summary, item.getSummary());

            Glide.with(mContext).load(item.getCover()).into((ImageView) helper.getView(R.id.recoding_iv_cover));
        }
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_home_request_qrcode;
    }

    @NonNull
    @Override
    public BasePresenter initPresenter() {
        return RequestQRCodePresenter.newInstance();
    }

    @Override
    public void hideKeybord() {

    }

    @Override
    public void back() {

    }

    @Override
    public void popToFragment(Class<?> targetFragmentClass, boolean includeTargetFragment) {

    }

    @Override
    public void startNewFragment(@NonNull SupportFragment supportFragment) {

    }

    @Override
    public void startNewFragmentWithPop(@NonNull SupportFragment supportFragment) {

    }

    @Override
    public void startNewFragmentForResult(@NonNull SupportFragment supportFragment, int requestCode) {

    }

    @Override
    public void setOnFragmentResult(int resultCode, Bundle data) {

    }

    @Override
    public void startNewActivity(@NonNull Class<?> clz) {

    }

    @Override
    public void startNewActivity(@NonNull Class<?> clz, Bundle bundle) {

    }

    @Override
    public void startNewActivityForResult(@NonNull Class<?> clz, Bundle bundle, int requestCode) {

    }

    @Override
    public boolean isVisiable() {
        return false;
    }

    @Override
    public Activity getBindActivity() {
        return null;
    }

    @Override
    public void showPhone(String phone) {

    }

    @Override
    public void showMessage(String message) {

    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        if (isVisibleToUser && !isInited) {
            initModel();
            isInited = true;
        }
    }
}
