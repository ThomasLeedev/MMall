package course.leedev.cn.pubgassistant.anim;

/**
 * Created by lt on 2017/12/31.
 *
 * Toolbar 动画 Manager
 */

public class ToolbarAnimManager {

    // TODO: 动画

}
