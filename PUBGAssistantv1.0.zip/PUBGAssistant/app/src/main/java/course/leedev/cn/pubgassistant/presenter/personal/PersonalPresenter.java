package course.leedev.cn.pubgassistant.presenter.personal;

import android.support.annotation.NonNull;

import course.leedev.cn.pubgassistant.contract.home.HomeMainContract;
import course.leedev.cn.pubgassistant.contract.personal.PersonalContract;
import course.leedev.cn.pubgassistant.model.home.HomeMainModel;
import course.leedev.cn.pubgassistant.model.personal.PersonalModel;

/**
 * Created by lt on 2017/12/31.
 */

public class PersonalPresenter extends PersonalContract.PersonalPresenter {

    @NonNull
    public static PersonalPresenter newInstance() {
        return new PersonalPresenter();
    }

    @Override
    public void getTabList() {
        if (mIView == null || mIModel == null) {
            return;
        }
        mIView.showTabList(mIModel.getTabs());
    }

    @Override
    public PersonalContract.IPersonalModel getModel() {
        return PersonalModel.newInstance();
    }

    @Override
    protected void onStart() {

    }
}
