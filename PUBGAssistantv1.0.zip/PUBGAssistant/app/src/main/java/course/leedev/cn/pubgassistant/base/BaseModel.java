package course.leedev.cn.pubgassistant.base;

/**
 * Created by lt on 2017/12/21.
 */

public abstract class BaseModel {

    public BaseModel() {

    }

}
