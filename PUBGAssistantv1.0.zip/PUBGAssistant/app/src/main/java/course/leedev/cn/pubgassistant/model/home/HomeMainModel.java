package course.leedev.cn.pubgassistant.model.home;

import android.support.annotation.NonNull;

import course.leedev.cn.pubgassistant.base.BaseModel;
import course.leedev.cn.pubgassistant.contract.home.HomeMainContract;

/**
 * Created by lt on 2017/12/30.
 *
 * 助手主页 model
 */

public class HomeMainModel extends BaseModel implements HomeMainContract.IHomeMainModel {

    @NonNull
    public static HomeMainModel newInstance() {
        return new HomeMainModel();
    }

    @Override
    public String[] getTabs() {
        return new String[]{"直播教学", "认证录播", "优秀文章"};
    }

}
