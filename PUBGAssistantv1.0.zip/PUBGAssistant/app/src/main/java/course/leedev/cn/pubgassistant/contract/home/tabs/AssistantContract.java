package course.leedev.cn.pubgassistant.contract.home.tabs;

/**
 * Created by lt on 2018/1/3.
 */

public interface AssistantContract {



}
