package course.leedev.cn.pubgassistant.ui.activity;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.scwang.smartrefresh.header.material.CircleImageView;
import com.vondear.rxtools.RxBarTool;
import com.vondear.rxtools.view.RxTitle;

import butterknife.BindView;
import butterknife.OnClick;
import course.leedev.cn.pubgassistant.R;
import course.leedev.cn.pubgassistant.base.activity.BaseActivity;
import course.leedev.cn.pubgassistant.model.User;
import course.leedev.cn.pubgassistant.model.pet;

public class InfoActivity extends BaseActivity {

    @BindView(R.id.rx_title)
    RxTitle mRxTitle;
    @BindView(R.id.tv_bg)
    TextView mTvBg;
    @BindView(R.id.iv_avatar)
    de.hdodenhof.circleimageview.CircleImageView mIvAvatar;
    @BindView(R.id.ll_anchor_left)
    LinearLayout mLlAnchorLeft;
    @BindView(R.id.rl_avatar)
    RelativeLayout mRlAvatar;
    @BindView(R.id.tv_name)
    TextView mTvName;
    @BindView(R.id.tv_qq)
    TextView mTvQQ;
    @BindView(R.id.tv_phone)
    TextView mTvPhone;
    @BindView(R.id.tv_address)
    TextView mTvAddress;
    @BindView(R.id.info_tv_username)
    TextView mTvUsername;

    @Override
    protected int getLayoutId() {
        RxBarTool.noTitle(this);
        return R.layout.activity_info;
    }

    @Override
    protected void initView(Bundle savedInstanceState) {
        mRxTitle.setLeftFinish(this);

        initUser();
    }

    private void initUser() {
        final Intent intent = getIntent();
        final Bundle bundle = intent.getBundleExtra("pet_user");
        final User pet_user = (User) bundle.getSerializable("pet_user");

        Glide.with(this).load(pet_user.getAvatar()).into(mIvAvatar);

        mTvName.setText(pet_user.getNickname());
        mTvPhone.setText(pet_user.getMobilePhoneNumber());
        mTvQQ.setText(pet_user.getQq());
        mTvAddress.setText(pet_user.getAddress());
        mTvUsername.setText(pet_user.getUsername());
    }
}
