package course.leedev.cn.pubgassistant.ui.fragment.news.child.tabs;

import android.graphics.Canvas;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseItemDraggableAdapter;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.chad.library.adapter.base.callback.ItemDragAndSwipeCallback;
import com.chad.library.adapter.base.listener.OnItemDragListener;
import com.chad.library.adapter.base.listener.OnItemSwipeListener;
import com.vondear.rxtools.view.RxToast;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobRealTimeData;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.DeleteListener;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.ValueEventListener;
import course.leedev.cn.pubgassistant.R;
import course.leedev.cn.pubgassistant.base.BasePresenter;
import course.leedev.cn.pubgassistant.base.IBaseModel;
import course.leedev.cn.pubgassistant.base.fragment.BaseCompatFragment;
import course.leedev.cn.pubgassistant.contract.home.tabs.RequestQRCodeContract;
import course.leedev.cn.pubgassistant.global.GlobalApplication;
import course.leedev.cn.pubgassistant.model.User;
import course.leedev.cn.pubgassistant.model.home.tabs.Article;
import course.leedev.cn.pubgassistant.model.request.tabs.Message;
import course.leedev.cn.pubgassistant.model.request.tabs.NewMessage;
import me.yuqirong.cardswipelayout.CardItemTouchHelperCallback;
import me.yuqirong.cardswipelayout.CardLayoutManager;
import me.yuqirong.cardswipelayout.OnSwipeListener;

/**
 * Created by lt on 2017/12/31.
 */

public class MessageFragment extends BaseCompatFragment<BasePresenter<RequestQRCodeContract.IRequestQRCodeModel, RequestQRCodeContract.IRequestQRCodeView>, IBaseModel> {

    @BindView(R.id.message_rv)
    RecyclerView recyclerView;

    List<Message> messages = new ArrayList<>();

    private OnItemSwipeListener onItemSwipeListener;
//    private OnItemDragListener onItemDragListener;

    public static MessageFragment newInstance() {
        Bundle args = new Bundle();
        MessageFragment assistantFragment = new MessageFragment();
        assistantFragment.setArguments(args);
        return assistantFragment;
    }

    @Override
    protected void initUI(View view, Bundle savedInstanceState) {
        initView();
        refresh();
//        refresh();
    }

    private void initView() {
        // dataList means dataSource for adapter

//        onItemDragListener = new OnItemDragListener() {
//            @Override
//            public void onItemDragStart(RecyclerView.ViewHolder viewHolder, int pos){}
//            @Override
//            public void onItemDragMoving(RecyclerView.ViewHolder source, int from, RecyclerView.ViewHolder target, int to) {}
//            @Override
//            public void onItemDragEnd(RecyclerView.ViewHolder viewHolder, int pos) {}
//        };
//
        onItemSwipeListener = new OnItemSwipeListener() {
            @Override
            public void onItemSwipeStart(RecyclerView.ViewHolder viewHolder, int pos) {}
            @Override
            public void clearView(RecyclerView.ViewHolder viewHolder, int pos) {}
            @Override
            public void onItemSwiped(RecyclerView.ViewHolder viewHolder, final int pos) {
                if (messages != null) {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            Message message = new Message();
                            Log.d("ltltlt", "runrunrun: " + messages);
                            message.setObjectId(messages.get(pos).getObjectId());
                            message.delete(getContext(), new DeleteListener() {
                                @Override
                                public void onSuccess() {
                                    RxToast.normal("删除成功");
                                }

                                @Override
                                public void onFailure(int i, String s) {
                                    RxToast.normal("删除失败");
                                }
                            });
                        }
                    }).start();
                }
            }

            @Override
            public void onItemSwipeMoving(Canvas canvas, RecyclerView.ViewHolder viewHolder, float dX, float dY, boolean isCurrentlyActive) {

            }
        };

//        initData();
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_request_message;
    }

    public class HomeAdapter extends BaseItemDraggableAdapter<Message, BaseViewHolder> {
        public HomeAdapter(int layoutResId, List data) {
            super(layoutResId, data);
            Log.d(TAG, "HomeAdapter: " + data.size());
        }

        @Override
        protected void convert(BaseViewHolder helper, Message item) {
            helper.setText(R.id.message_tv_summary, "为您的" + item.getPetName() + "点赞！");
            Glide.with(getContext()).load(item.getFromAvatar()).into((ImageView) helper.getView(R.id.message_iv_avatar));
            helper.setText(R.id.message_tv_username, item.getUserName());
//            Glide.with(mContext).load(item.getUserAvatar()).crossFade().into((ImageView) helper.getView(R.id.iv));
        }
    }

    public void refresh() {
                BmobQuery<Message> query = new BmobQuery<>();
                //查询playerName叫“比目”的数据
                query.addWhereEqualTo("touser", User.getCurrentUser(getContext()).getObjectId());
                Log.d("ltltlt", "onSuccess: " + User.getCurrentUser(getContext()).getUsername());
                //执行查询方法
                query.findObjects(getContext(), new FindListener<Message>() {
                    @Override
                    public void onSuccess(List<Message> list) {

                        Log.d(TAG, "onSuccess: " + list);

                        for (Message m :
                                list) {
                            Log.d("ltltlt", "onSuccess: " + m.getPetName() + "  from:" + m.getUserName());
                        }

                        messages.addAll(list);

                        HomeAdapter adapter = new HomeAdapter(R.layout.item_fragment_request_message, list);

                        // 开启拖拽
//        adapter.enableDragItem(itemTouchHelper, R.id.textView, true);
//        adapter.setOnItemDragListener(onItemDragListener);

                        // 开启滑动删除


                                adapter.openLoadAnimation();
                                ItemDragAndSwipeCallback itemDragAndSwipeCallback = new ItemDragAndSwipeCallback(adapter);
                                ItemTouchHelper itemTouchHelper = new ItemTouchHelper(itemDragAndSwipeCallback);
                                itemTouchHelper.attachToRecyclerView(recyclerView);
                                adapter.enableSwipeItem();
                                adapter.setOnItemSwipeListener(onItemSwipeListener);
                                recyclerView.setAdapter(adapter);
                                recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

                    }

                    @Override
                    public void onError(int i, String s) {

                    }
                });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
//            refresh();
        }
    }
}
