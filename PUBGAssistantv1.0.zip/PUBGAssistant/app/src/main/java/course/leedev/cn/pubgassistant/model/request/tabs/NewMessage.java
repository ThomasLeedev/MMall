package course.leedev.cn.pubgassistant.model.request.tabs;

import cn.bmob.v3.BmobObject;

public class NewMessage extends BmobObject {

    private String userId;
    private String badge;

    public String getBadge() {
        return badge;
    }

    public void setBadge(String badge) {
        this.badge = badge;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}