package course.leedev.cn.pubgassistant.ui.fragment.home.child.tabs;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.wx.goodview.GoodView;

import butterknife.BindView;
import course.leedev.cn.pubgassistant.R;
import course.leedev.cn.pubgassistant.base.BasePresenter;
import course.leedev.cn.pubgassistant.base.IBaseModel;
import course.leedev.cn.pubgassistant.base.fragment.BaseCompatFragment;
import course.leedev.cn.pubgassistant.contract.home.tabs.RequestQRCodeContract;
import q.rorbin.badgeview.Badge;
import q.rorbin.badgeview.QBadgeView;

/**
 * Created by lt on 2017/12/31.
 */

public class AssistantFragment extends BaseCompatFragment<BasePresenter<RequestQRCodeContract.IRequestQRCodeModel, RequestQRCodeContract.IRequestQRCodeView>, IBaseModel> {

    @BindView(R.id.nozhi)
    TextView no;

    public static AssistantFragment newInstance() {
        Bundle args = new Bundle();
        AssistantFragment assistantFragment = new AssistantFragment();
        assistantFragment.setArguments(args);
        return assistantFragment;
    }

    @Override
    protected void initUI(View view, Bundle savedInstanceState) {

//        final GoodView goodView = new GoodView(getContext());
//        no.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                goodView.setText("+1");
//                goodView.show(v);
//            }
//        });
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_home_assistant;
    }
}
