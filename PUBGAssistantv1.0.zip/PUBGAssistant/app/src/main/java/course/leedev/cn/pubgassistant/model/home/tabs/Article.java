package course.leedev.cn.pubgassistant.model.home.tabs;

import cn.bmob.v3.BmobObject;

/**
 * Created by lt on 18-5-23.
 */

public class Article extends BmobObject {

    private String title;
    private String author;
    private String data;
    private String cover; //封面图片地址
    private String summary; //摘要
    private String link;

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
