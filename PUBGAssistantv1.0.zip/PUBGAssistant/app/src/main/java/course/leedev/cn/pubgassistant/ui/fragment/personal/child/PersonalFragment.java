package course.leedev.cn.pubgassistant.ui.fragment.personal.child;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.zxing.Result;
import com.vondear.rxtools.RxActivityTool;
import com.vondear.rxtools.RxPhotoTool;
import com.vondear.rxtools.activity.ActivityScanerCode;
import com.vondear.rxtools.interfaces.OnRxScanerListener;
import com.vondear.rxtools.view.RxToast;
import com.vondear.rxtools.view.dialog.RxDialogEditSureCancel;
import com.vondear.rxtools.view.dialog.RxDialogSureCancel;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.GetListener;
import cn.bmob.v3.listener.UpdateListener;
import course.leedev.cn.pubgassistant.R;
import course.leedev.cn.pubgassistant.adapter.FragmentAdapter;
import course.leedev.cn.pubgassistant.base.BasePresenter;
import course.leedev.cn.pubgassistant.base.fragment.BaseMVPCompatFragment;
import course.leedev.cn.pubgassistant.constant.AllPro;
import course.leedev.cn.pubgassistant.contract.personal.PersonalContract;
import course.leedev.cn.pubgassistant.global.GlobalApplication;
import course.leedev.cn.pubgassistant.model.pet;
import course.leedev.cn.pubgassistant.model.User;
import course.leedev.cn.pubgassistant.presenter.personal.PersonalPresenter;
import course.leedev.cn.pubgassistant.ui.activity.AddPetActivity;
import course.leedev.cn.pubgassistant.ui.activity.InfoActivity;
import course.leedev.cn.pubgassistant.ui.activity.LoginActivity;
import course.leedev.cn.pubgassistant.ui.activity.MainActivity;
import course.leedev.cn.pubgassistant.ui.activity.PetActivity;
import course.leedev.cn.pubgassistant.ui.activity.SimpleCaptureActivity;
import course.leedev.cn.pubgassistant.ui.fragment.home.child.tabs.AssistantFragment;
import course.leedev.cn.pubgassistant.ui.fragment.home.child.tabs.RegisterFragment;
import course.leedev.cn.pubgassistant.ui.fragment.home.child.tabs.RequestQRCodeFragment;
import course.leedev.cn.pubgassistant.ui.fragment.personal.child.tabs.CollectionFragment;
import course.leedev.cn.pubgassistant.ui.fragment.personal.child.tabs.PetsFragment;
import course.leedev.cn.pubgassistant.utils.AppUtils;
import de.hdodenhof.circleimageview.CircleImageView;
import io.github.xudaojie.qrcodelib.CaptureActivity;
import me.yokeyword.fragmentation.SupportFragment;

import static com.just.agentweb.ActionActivity.REQUEST_CODE;

/**
 * Created by lt on 2017/12/21.
 *
 * 助手页面
 */

public class PersonalFragment extends BaseMVPCompatFragment<PersonalContract.PersonalPresenter,
        PersonalContract.IPersonalModel> implements PersonalContract.IPersonalView {

    @BindView(R.id.person_app_bar)
    AppBarLayout appBar;
    @BindView(R.id.person_tool_bar)
    Toolbar toolbar;
    @BindView(R.id.person_tl_tab)
    TabLayout tlTabs;
    @BindView(R.id.person_vp_fragment)
    ViewPager vpFragment;
    @BindView(R.id.iv_avatar)
    CircleImageView ivAvatar;
    @BindView(R.id.tv_nick)
    TextView tvNick;

    private List<Fragment> fragments;

    public static PersonalFragment newInstance() {
        Bundle args = new Bundle();
        PersonalFragment fragment  = new PersonalFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        fragments = new ArrayList<>();
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onLazyInitView(@Nullable Bundle savedInstanceState) {
        super.onLazyInitView(savedInstanceState);
        mPresenter.getTabList();
    }

    @Override
     public int getLayoutId() {
        return R.layout.fragment_person_;
    }

    @Override
    protected void initUI(View view, Bundle savedInstanceState) {

//        toolbar.setTitle("");
        toolbar.inflateMenu(R.menu.toolbar_menu);
        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.exit_login:
                        final RxDialogSureCancel exitDialog = new RxDialogSureCancel(getActivity());
                        exitDialog.setSureListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                User.logOut(mContext);
                                exitDialog.dismiss();
                                startActivity(new Intent(getActivity(), LoginActivity.class));
                                getActivity().finish();
                            }
                        });
                        exitDialog.setCancelListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                exitDialog.dismiss();
                            }
                        });
                        exitDialog.show();
                        break;
                        //二维码扫描
                    case R.id.scan_code:
                        //zxing二维码扫描
//                        Intent intent = new Intent(getContext(), CaptureActivity.class);
//                        startActivityForResult(intent, REQUEST_CODE);



                        //原来的二维码扫描代码
                        /*ActivityScanerCode.setScanerListener(new OnRxScanerListener() {
                            @Override
                            public void onSuccess(String s, final Result result) {
                                BmobQuery<pet> query = new BmobQuery<pet>();
                                query.getObject(getContext(), result.getText(), new GetListener<pet>() {
                                    @Override
                                    public void onSuccess(pet pet) {
//                                        Intent intent = new Intent(getContext(), PetActivity.class);
//                                        Bundle bundle = new Bundle();
//                                        bundle.putSerializable("pet", pet);
//                                        intent.putExtra("pet", bundle);
//
//                                        startActivity(intent);
//                                        RxActivityTool.finishActivity();
                                    }

                                    @Override
                                    public void onFailure(int i, String s) {

                                    }
                                });
                            }

                            @Override
                            public void onFail(String s, String s1) {

                            }
                        });*/
                        Intent i = new Intent(getContext(), SimpleCaptureActivity.class);
                        startActivity(i);
                        break;

                    case R.id.change_info:
                        Intent intent = new Intent(GlobalApplication.getContext(), InfoActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("pet_user", GlobalApplication.getUser());
                        intent.putExtra("pet_user", bundle);

                        RxToast.normal("暂不支持修改个人信息");

                        startActivity(intent);
                        break;

                    case R.id.add_pet:
                        startActivity(new Intent(getContext(), AddPetActivity.class));
                        break;

                    /*case R.id.change_pass:

                        final RxDialogEditSureCancel oldPass = new RxDialogEditSureCancel(getActivity());
                        oldPass.setTitle("请输入旧密码");
                        oldPass.getCancelView().setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                oldPass.dismiss();
                            }
                        });
                        oldPass.getSureView().setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                oldPass.dismiss();

                                final RxDialogEditSureCancel newPass = new RxDialogEditSureCancel(getActivity());
                                newPass.setTitle("请输入新密码");
                                newPass.getCancelView().setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        newPass.dismiss();
                                    }
                                });
                                newPass.getSureView().setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        BmobUser.updateCurrentUserPassword(getContext(), oldPass.getEditText().getText().toString(), newPass.getEditText().getText().toString(), new UpdateListener() {
                                            @Override
                                            public void onSuccess() {
                                                RxToast.normal("修改成功");
                                            }

                                            @Override
                                            public void onFailure(int i, String s) {
                                                RxToast.normal(s);
                                            }
                                        });
                                    }
                                });
                                newPass.show();
                            }
                        });
                        oldPass.show();

                        break;*/
                }
                return false;
            }
        });

        //头像设置
//        Glide.with(mContext).load()

//        ivAvatar.setImageResource(R.drawable.img_avatar_01);

        User user = BmobUser.getCurrentUser(getContext(), User.class);

        Glide.with(getContext()).load(user.getAvatar()).into(ivAvatar);

        tvNick.setText(user.getNickname());

        System.out.println("ni" + user.getAvatar());

        ivAvatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Album.initialize(AlbumConfig.newBuilder(mContext)
//                        .setAlbumLoader(new MediaLoader())
//                        .setLocale(Locale.CHINESE)
//                        .build());
//                Album.image(mContext) // Image selection.
//                        .multipleChoice()
//                        .camera(false)
//                        .columnCount(2)
//                        .selectCount(1)
//                        .onResult(new Action<ArrayList<AlbumFile>>() {
//                            @Override
//                            public void onAction(@NonNull ArrayList<AlbumFile> result) {
//                                ivAvatar.setImageBitmap(BitmapFactory.decodeFile(result.get(0).getPath()));
//                            }
//                        })
//                        .onCancel(new Action<String>() {
//                            @Override
//                            public void onAction(@NonNull String result) {
//                            }
//                        })
//                        .start();

//                Toast.makeText(mContext, AllPro.getUser(mContext).getAvatar(), Toast.LENGTH_SHORT).show();


            }
        });

        // TODO: toolbar 动画
    }

    @NonNull
    @Override
    public BasePresenter initPresenter() {
        return PersonalPresenter.newInstance();
    }

    @Override
    public void back() {

    }

    @Override
    public void popToFragment(Class<?> targetFragmentClass, boolean includeTargetFragment) {

    }

    @Override
    public void startNewFragment(@NonNull SupportFragment supportFragment) {

    }

    @Override
    public void startNewFragmentWithPop(@NonNull SupportFragment supportFragment) {

    }

    @Override
    public void startNewFragmentForResult(@NonNull SupportFragment supportFragment, int requestCode) {

    }

    @Override
    public void setOnFragmentResult(int resultCode, Bundle data) {

    }

    @Override
    public void startNewActivity(@NonNull Class<?> clz) {

    }

    @Override
    public void startNewActivity(@NonNull Class<?> clz, Bundle bundle) {

    }

    @Override
    public void startNewActivityForResult(@NonNull Class<?> clz, Bundle bundle, int requestCode) {

    }

    @Override
    public void showTabList(String[] tabs) {
        for (int i = 0; i < tabs.length; i++) {
            tlTabs.addTab(tlTabs.newTab().setText(tabs[i]));
            switch (i) {
                case 0:
                    fragments.add(PetsFragment.newInstance());
                    break;
                /*case 1:
                    fragments.add(CollectionFragment.newInstance());
                    break;
                case 2:
                    fragments.add(RegisterFragment.newInstance());
                    break;*/
                default:
                    fragments.add(AssistantFragment.newInstance());
                    break;
            }
        }
        vpFragment.setAdapter(new FragmentAdapter(getChildFragmentManager(), fragments));
        vpFragment.setCurrentItem(0);
        vpFragment.setOffscreenPageLimit(2);
        tlTabs.setupWithViewPager(vpFragment);
        tlTabs.setVerticalScrollbarPosition(0);
        for (int i = 0; i < tabs.length; i++) {
            tlTabs.getTabAt(i).setText(tabs[i]);
        }
    }

    /**
     * fragment 打开 DrawerLayout 监听
     */
    public interface OnOpenDrawerLayoutListener {
        void onOpen();
    }
}
