package course.leedev.cn.pubgassistant.ui.fragment.news.child.tabs;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.vondear.rxtools.view.RxToast;
import com.vondear.rxtools.view.likeview.RxShineButton;
import com.wx.goodview.GoodView;

import net.lingala.zip4j.util.Raw;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.GetListener;
import cn.bmob.v3.listener.SaveListener;
import cn.bmob.v3.listener.UpdateListener;
import course.leedev.cn.pubgassistant.R;
import course.leedev.cn.pubgassistant.base.BasePresenter;
import course.leedev.cn.pubgassistant.base.IBaseModel;
import course.leedev.cn.pubgassistant.base.fragment.BaseCompatFragment;
import course.leedev.cn.pubgassistant.contract.home.tabs.RequestQRCodeContract;
import course.leedev.cn.pubgassistant.global.GlobalApplication;
import course.leedev.cn.pubgassistant.model.User;
import course.leedev.cn.pubgassistant.model.pet;
import course.leedev.cn.pubgassistant.model.request.tabs.Message;
import course.leedev.cn.pubgassistant.model.request.tabs.NewMessage;
import course.leedev.cn.pubgassistant.ui.activity.MainActivity;
import course.leedev.cn.pubgassistant.utils.AgeUtils;
import me.yuqirong.cardswipelayout.CardConfig;
import me.yuqirong.cardswipelayout.CardItemTouchHelperCallback;
import me.yuqirong.cardswipelayout.CardLayoutManager;
import me.yuqirong.cardswipelayout.OnSwipeListener;

/**
 * Created by lt on 2017/12/31.
 */

public class SocialFragment extends BaseCompatFragment<BasePresenter<RequestQRCodeContract.IRequestQRCodeModel, RequestQRCodeContract.IRequestQRCodeView>, IBaseModel> {

    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;

    private List<pet> list = new ArrayList<>();
    private boolean isInited = false;

    public static SocialFragment newInstance() {
        Bundle args = new Bundle();
        SocialFragment assistantFragment = new SocialFragment();
        assistantFragment.setArguments(args);
        return assistantFragment;
    }

    @Override
    protected void initUI(View view, Bundle savedInstanceState) {
        initData();
    }

    private void initView(List<pet> list) {

        this.list = list;

        // dataList means dataSource for adapter
        recyclerView.setAdapter(new MyAdapter());
        CardItemTouchHelperCallback cardCallback = new CardItemTouchHelperCallback(recyclerView.getAdapter(), list);
        ItemTouchHelper touchHelper = new ItemTouchHelper(cardCallback);
        CardLayoutManager cardLayoutManager = new CardLayoutManager(recyclerView, touchHelper);
        recyclerView.setLayoutManager(cardLayoutManager);
        touchHelper.attachToRecyclerView(recyclerView);
        cardCallback.setOnSwipedListener(new OnSwipeListener() {
            @Override
            public void onSwiping(RecyclerView.ViewHolder viewHolder, float ratio, int direction) {

            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, Object o, int direction) {
                RxShineButton btnShine = viewHolder.itemView.findViewById(R.id.iv_like);
                btnShine.setChecked(false);

                System.out.println("one page");
            }

            @Override
            public void onSwipedClear() {

            }
        });
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_request_social;
    }

    private class MyAdapter extends RecyclerView.Adapter {
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item, parent, false);
            return new MyViewHolder(view);
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
            ImageView avatarImageView = ((MyViewHolder) holder).avatarImageView;
            final RxShineButton likeImageView = ((MyViewHolder) holder).likeImageView;

            TextView tvAge = ((MyViewHolder) holder).tvAge;
            TextView tvCategory = ((MyViewHolder) holder).tvCategory;
            TextView tvCharacter = ((MyViewHolder) holder).tvCharacter;
            TextView tvName = ((MyViewHolder) holder).tvName;

            Glide.with(getContext()).load(list.get(position).getAvatar()).into(avatarImageView);

            likeImageView.init(getActivity());
            likeImageView.setShapeResource(R.raw.heart);

            // 点击爱心触发事件
            likeImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (likeImageView.isChecked()) {
                        final Message message = new Message();
                        message.setFromAvatar(GlobalApplication.getUser().getAvatar());
                        message.setFromuser(GlobalApplication.getUser().getObjectId());
                        message.setTouser(list.get(position).getUserid());
                        message.setPetId(list.get(position).getObjectId());
                        message.setPetName(list.get(position).getName());
                        message.setUserName(GlobalApplication.getUser().getNickname());

                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                message.save(getContext(), new SaveListener() {
                                    @Override
                                    public void onSuccess() {
                                        RxToast.normal("请求发送成功");
                                    }

                                    @Override
                                    public void onFailure(int i, String s) {

                                    }
                                });

                                /*BmobQuery<User> query = new BmobQuery<User>();
                                query.getObject(getContext(), list.get(position).getUserid(), new GetListener<User>() {
                                    @Override
                                    public void onSuccess(final User cUser) {

                                        BmobQuery<NewMessage> query1 = new BmobQuery<>();
                                        query1.addWhereEqualTo("userid", cUser.getObjectId());
                                        query1.findObjects(getContext(), new FindListener<NewMessage>() {
                                            @Override
                                            public void onSuccess(List<NewMessage> list) {
                                                if (list == null) {
                                                    NewMessage message1 = new NewMessage();
                                                    message1.setUserId(cUser.getObjectId());
                                                    message1.setBadge("1");
                                                } else {
                                                    int num = 1;
                                                    NewMessage message1 = list.get(0);
                                                    if (message1.getBadge() == null) {
                                                        num = Integer.parseInt(message1.getBadge()) + 1;
                                                    }
                                                    NewMessage user = new NewMessage();
                                                    user.setBadge("" + num);
                                                    user.update(getContext(), message1.getObjectId(), new UpdateListener() {
                                                        @Override
                                                        public void onSuccess() {
                                                            Log.d("bilibili", "onSuccess: ");
                                                        }

                                                        @Override
                                                        public void onFailure(int i, String s) {
                                                            Log.d("bilibili", "onFail: " + s);
                                                        }
                                                    });
                                                }
                                            }

                                            @Override
                                            public void onError(int i, String s) {

                                            }
                                        });


                                        *//*int num = 1;

                                        if (cUser.getBadge() != null) {
                                            num = Integer.parseInt(cUser.getBadge()) + 1;
                                            Log.d("bilibili", "onSuccess: " + cUser.getNickname() + cUser.getBadge() + "num:" + num);
                                        }

                                        User user = new User();
                                        user.setBadge("" + num);
                                        user.update(getContext(), cUser.getObjectId(), new UpdateListener() {
                                            @Override
                                            public void onSuccess() {
                                                Log.d("bilibili", "onSuccess: ");
                                            }

                                            @Override
                                            public void onFailure(int i, String s) {
                                                Log.d("bilibili", "onFail: " + s);
                                            }
                                        });*//*
                                    }

                                    @Override
                                    public void onFailure(int i, String s) {

                                    }
                                });*/
                            }

                        }).start();

                    }
                }
            });
            /*final GoodView goodView = new GoodView(getContext());
            likeImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    goodView.setImage(R.drawable.img_like);
                    goodView.show(v);
                }
            });*/
            if (list.get(position).getGender().equals("雄性")) {
                tvAge.setText("♂ " + AgeUtils.getAgeFromBirthTime(list.get(position).getBirthday()));
                tvAge.setBackground(getResources().getDrawable(R.drawable.shape_gender));
            } else {
                tvAge.setText("♀ " + AgeUtils.getAgeFromBirthTime(list.get(position).getBirthday()));
            }

            tvCategory.setText(list.get(position).getCategory());
            tvCharacter.setText(list.get(position).getCharacter());
            tvName.setText(list.get(position).getName());
        }

        @Override
        public int getItemCount() {
            Log.d(TAG, "getItemCount: " + list.size());
            return list.size();
        }

        class MyViewHolder extends RecyclerView.ViewHolder {

            ImageView avatarImageView;
            RxShineButton likeImageView;
            TextView tvAge;
            TextView tvCategory;
            TextView tvCharacter;
            TextView tvName;

            MyViewHolder(View itemView) {
                super(itemView);
                avatarImageView = (ImageView) itemView.findViewById(R.id.iv_avatar);
                likeImageView = (RxShineButton) itemView.findViewById(R.id.iv_like);
                tvAge = (TextView) itemView.findViewById(R.id.tv_age);
                tvCategory = (TextView) itemView.findViewById(R.id.tv_constellation);
                tvCharacter = (TextView) itemView.findViewById(R.id.tv_character);
                tvName = (TextView) itemView.findViewById(R.id.tv_name);
            }

        }
    }

    public void initData() {
                BmobQuery<pet> query = new BmobQuery<>();
                query.addWhereNotEqualTo("userid", User.getCurrentUser(getContext()).getObjectId());
                query.findObjects(getContext(), new FindListener<pet>() {
                    @Override
                    public void onSuccess(final List<pet> list) {
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                initView(list);
                            }
                        });
                    }

                    @Override
                    public void onError(int i, String s) {

                    }
                });
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser && !isInited) {
//            initData();
//            isInited = true;
        }
    }
}
