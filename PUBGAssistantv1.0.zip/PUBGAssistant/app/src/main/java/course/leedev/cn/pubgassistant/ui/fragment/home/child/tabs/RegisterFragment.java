package course.leedev.cn.pubgassistant.ui.fragment.home.child.tabs;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.listener.FindListener;
import course.leedev.cn.pubgassistant.R;
import course.leedev.cn.pubgassistant.base.fragment.BaseCompatFragment;
import course.leedev.cn.pubgassistant.model.home.tabs.Article;
import course.leedev.cn.pubgassistant.model.home.tabs.Video;
import course.leedev.cn.pubgassistant.ui.activity.VideoActivity;

/**
 * 文章页面
 *
 * Created by lt on 2018/1/8.
 */

public class RegisterFragment extends BaseCompatFragment {

    @BindView(R.id.register_rv)
    RecyclerView recyclerView;

    @BindView(R.id.article_refresh)
    SmartRefreshLayout smartRefreshLayout;

    private List<Article> list = new ArrayList<>();
    private boolean isInited = false;

    public static RegisterFragment newInstance() {
        return new RegisterFragment();
    }

    @Override
    protected void initUI(View view, Bundle savedInstanceState) {
        initRefresh();
    }

    private void initRefresh() {
        smartRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                initModel(refreshLayout);
            }
        });

        smartRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                refreshLayout.finishLoadMore(3000);
            }
        });
    }

    private void initModel(final RefreshLayout refreshLayout) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                BmobQuery<Article> query = new BmobQuery<>();
                query.findObjects(getContext(), new FindListener<Article>() {
                    @Override
                    public void onSuccess(List<Article> list) {
                        final HomeAdapter adapter = new HomeAdapter(R.layout.item_fragment_home_register, list);
                        adapter.openLoadAnimation();

                        adapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
                            @Override
                            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                                Intent intent = new Intent(getContext(), VideoActivity.class);
                                intent.putExtra(VideoActivity.VideoTitle, ((Article) adapter.getItem(position)).getTitle());
                                intent.putExtra(VideoActivity.VideoLink, ((Article) adapter.getItem(position)).getLink());
                                startActivity(intent);
                            }
                        });

                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                recyclerView.setAdapter(adapter);
                                recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

                                refreshLayout.finishRefresh(2000);
                            }
                        });

                    }

                    @Override
                    public void onError(int i, String s) {
                        Log.i("bmob","失败："+s);
                        refreshLayout.finishRefresh(2000, false);
                    }
                });
            }
        }).start();
    }

    private void initModel() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                BmobQuery<Article> query = new BmobQuery<>();

                query.findObjects(getContext(), new FindListener<Article>() {
                    @Override
                    public void onSuccess(List<Article> list) {
                        final HomeAdapter adapter = new HomeAdapter(R.layout.item_fragment_home_register, list);
                        adapter.openLoadAnimation();

                        adapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
                            @Override
                            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                                Intent intent = new Intent(getContext(), VideoActivity.class);
                                intent.putExtra(VideoActivity.VideoTitle, ((Article) adapter.getItem(position)).getTitle());
                                intent.putExtra(VideoActivity.VideoLink, ((Article) adapter.getItem(position)).getLink());
                                startActivity(intent);
                            }
                        });

                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                recyclerView.setAdapter(adapter);
                                recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                            }
                        });

                        System.out.println("hello");

                    }

                    @Override
                    public void onError(int i, String s) {
                        Log.i("bmob","失败："+s);
                    }
                });
            }
        }).start();
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_home_register;
    }

    public class HomeAdapter extends BaseQuickAdapter<Article, BaseViewHolder> {
        public HomeAdapter(int layoutResId, List data) {
            super(layoutResId, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, Article item) {
            Glide.with(getActivity()).load(item.getCover()).into((ImageView) helper.getView(R.id.article_iv_cover));
            helper.setText(R.id.article_tv_title, item.getTitle());
            helper.setText(R.id.article_tv_data, item.getCreatedAt());
            helper.setText(R.id.article_tv_summary, item.getSummary());
//            Glide.with(mContext).load(item.getUserAvatar()).crossFade().into((ImageView) helper.getView(R.id.iv));
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        if (isVisibleToUser && !isInited) {
            initModel();
            isInited = true;
        }
    }
}
