package course.leedev.cn.pubgassistant.ui.activity;

import android.content.Intent;
import android.os.Bundle;

import com.vondear.rxtools.RxActivityTool;
import com.vondear.rxtools.RxTool;
import com.vondear.rxtools.view.RxToast;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.listener.GetListener;
import course.leedev.cn.pubgassistant.model.pet;
import io.github.xudaojie.qrcodelib.CaptureActivity;

import static course.leedev.cn.pubgassistant.global.GlobalApplication.getContext;

public class SimpleCaptureActivity extends CaptureActivity {

    @Override
    protected void handleResult(String resultString) {
        super.handleResult(resultString);

        BmobQuery<pet> query = new BmobQuery<pet>();
        query.getObject(getContext(), resultString, new GetListener<pet>() {
            @Override
            public void onSuccess(pet pet) {
                Intent intent = new Intent(getContext(), PetActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("pet", pet);
                intent.putExtra("pet", bundle);

                startActivity(intent);
            }

            @Override
            public void onFailure(int i, String s) {
                restartPreview();
                RxToast.normal("没有找到该宠物");
            }
        });
    }
}
