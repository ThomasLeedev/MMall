package course.leedev.cn.pubgassistant.constant;

/**
 * Created by lgx on 2018/1/7.
 *
 * 请求验证码类中的常量值
 */

public class RequestQRCodeConstant {

}
