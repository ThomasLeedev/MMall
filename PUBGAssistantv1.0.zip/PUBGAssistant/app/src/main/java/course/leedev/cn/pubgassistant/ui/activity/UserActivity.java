package course.leedev.cn.pubgassistant.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.vondear.rxtools.view.RxToast;

import butterknife.BindView;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.listener.GetListener;
import course.leedev.cn.pubgassistant.R;
import course.leedev.cn.pubgassistant.base.activity.BaseActivity;
import course.leedev.cn.pubgassistant.model.User;
import course.leedev.cn.pubgassistant.model.pet;
import de.hdodenhof.circleimageview.CircleImageView;

import static course.leedev.cn.pubgassistant.utils.AppUtils.getContext;

/**
 * Created by lt on 18-6-17.
 */

public class UserActivity extends BaseActivity {



    @Override
    protected int getLayoutId() {
        return R.layout.activity_pet;
    }

    @Override
    protected void initView(Bundle savedInstanceState) {


    }
}
