package course.leedev.cn.pubgassistant.model.personal;

import cn.bmob.v3.BmobObject;

public class Collection extends BmobObject {

    private String userid;
    private String articleid;

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getArticleid() {
        return articleid;
    }

    public void setArticleid(String articleid) {
        this.articleid = articleid;
    }
}
