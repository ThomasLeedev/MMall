package course.leedev.cn.pubgassistant.ui.fragment.news.child;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.GetListener;
import cn.bmob.v3.listener.UpdateListener;
import course.leedev.cn.pubgassistant.R;
import course.leedev.cn.pubgassistant.adapter.FragmentAdapter;
import course.leedev.cn.pubgassistant.base.BasePresenter;
import course.leedev.cn.pubgassistant.base.fragment.BaseMVPCompatFragment;
import course.leedev.cn.pubgassistant.contract.request.RequestContract;
import course.leedev.cn.pubgassistant.model.User;
import course.leedev.cn.pubgassistant.model.request.tabs.NewMessage;
import course.leedev.cn.pubgassistant.presenter.request.RequestPresenter;
import course.leedev.cn.pubgassistant.ui.activity.LoginActivity;
import course.leedev.cn.pubgassistant.ui.fragment.home.child.HomeFragment;
import course.leedev.cn.pubgassistant.ui.fragment.home.child.tabs.AssistantFragment;
import course.leedev.cn.pubgassistant.ui.fragment.home.child.tabs.RegisterFragment;
import course.leedev.cn.pubgassistant.ui.fragment.home.child.tabs.RequestQRCodeFragment;
import course.leedev.cn.pubgassistant.ui.fragment.news.child.tabs.MessageFragment;
import course.leedev.cn.pubgassistant.ui.fragment.news.child.tabs.SocialFragment;
import me.yokeyword.fragmentation.SupportFragment;
import q.rorbin.badgeview.Badge;
import q.rorbin.badgeview.QBadgeView;

/**
 * Created by lt on 18-5-23.
 */

public class RequestFragment extends BaseMVPCompatFragment<RequestContract.RequestPresenter,
        RequestContract.IRequestModel> implements RequestContract.IRequestView {
    @BindView(R.id.request_app_bar)
    AppBarLayout appBar;
    @BindView(R.id.request_tool_bar)
    Toolbar toolbar;
    @BindView(R.id.request_tl_tab)
    TabLayout tlTabs;
    @BindView(R.id.request_vp_fragment)
    ViewPager vpFragment;

    private List<Fragment> fragments;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    public static RequestFragment newInstance() {
        Bundle args = new Bundle();
        RequestFragment fragment  = new RequestFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        fragments = new ArrayList<>();
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onLazyInitView(@Nullable Bundle savedInstanceState) {
        super.onLazyInitView(savedInstanceState);
        mPresenter.getTabList();
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_request_;
    }

    @Override
    protected void initUI(View view, Bundle savedInstanceState) {

        sharedPreferences = getContext().getSharedPreferences("user", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();

        toolbar.setTitle("");

        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.exit_login:
                        editor.putBoolean("logined", false);
                        startActivity(new Intent(getContext(), LoginActivity.class));
                        getActivity().finish();
                        break;
                }
                return false;
            }
        });
        // TODO: toolbar 动画
    }

    @NonNull
    @Override
    public BasePresenter initPresenter() {
        return RequestPresenter.newInstance();
    }

    @Override
    public void back() {

    }

    @Override
    public void popToFragment(Class<?> targetFragmentClass, boolean includeTargetFragment) {

    }

    @Override
    public void startNewFragment(@NonNull SupportFragment supportFragment) {

    }

    @Override
    public void startNewFragmentWithPop(@NonNull SupportFragment supportFragment) {

    }

    @Override
    public void startNewFragmentForResult(@NonNull SupportFragment supportFragment, int requestCode) {

    }

    @Override
    public void setOnFragmentResult(int resultCode, Bundle data) {

    }

    @Override
    public void startNewActivity(@NonNull Class<?> clz) {

    }

    @Override
    public void startNewActivity(@NonNull Class<?> clz, Bundle bundle) {

    }

    @Override
    public void startNewActivityForResult(@NonNull Class<?> clz, Bundle bundle, int requestCode) {

    }

    @Override
    public void showTabList(String[] tabs) {
        for (int i = 0; i < tabs.length; i++) {
            tlTabs.addTab(tlTabs.newTab().setText(tabs[i]));
            switch (i) {
                case 0:
                    fragments.add(SocialFragment.newInstance());
                    break;
                case 1:
                    fragments.add(MessageFragment.newInstance());
                    break;
                default:
                    fragments.add(SocialFragment.newInstance());
                    break;
            }
        }
        vpFragment.setAdapter(new FragmentAdapter(getChildFragmentManager(), fragments));
        vpFragment.setCurrentItem(0);
        vpFragment.setOffscreenPageLimit(2);
        tlTabs.setupWithViewPager(vpFragment);
        tlTabs.setVerticalScrollbarPosition(0);
        for (int i = 0; i < tabs.length; i++) {
            tlTabs.getTabAt(i).setText(tabs[i]);
        }

        Log.d("ltltlt", User.getCurrentUser(getContext(), User.class).getNickname());

        /*BmobQuery<NewMessage> query = new BmobQuery<>();
        query.addWhereEqualTo("userId", User.getCurrentUser(getContext(), User.class).getObjectId());
        query.findObjects(getContext(), new FindListener<NewMessage>() {
            @Override
            public void onSuccess(List<NewMessage> list) {
                int num = 0;
                if (list != null) {
                    final NewMessage newMessage = list.get(0);
                    if (newMessage.getBadge() != null && !newMessage.getBadge().equals("0")) {
                        String nowNum = newMessage.getBadge();
                        num = num + Integer.parseInt(nowNum);
                        new QBadgeView(getContext()).bindTarget(((ViewGroup) tlTabs.getChildAt(0)).getChildAt(1))
                                .setBadgeNumber(num)
                                .setGravityOffset(50, 0, true)
                                .setOnDragStateChangedListener(new Badge.OnDragStateChangedListener() {
                                    @Override
                                    public void onDragStateChanged(int dragState, Badge badge, View targetView) {
                                        if (dragState == 5) {
                                            NewMessage user = new NewMessage();
                                            user.setBadge("0");
                                            user.update(getContext(), newMessage.getObjectId(), new UpdateListener() {
                                                @Override
                                                public void onSuccess() {

                                                }

                                                @Override
                                                public void onFailure(int i, String s) {

                                                }
                                            });
                                        }
                                    }
                                });
                    }
                }
            }

            @Override
            public void onError(int i, String s) {

            }
        });*/

        /*if (User.getCurrentUser(getContext(), User.class).getBadge() != null && !User.getCurrentUser(getContext(), User.class).getBadge().equals("0")) {
            String nowNum = User.getCurrentUser(getContext(), User.class).getBadge();
            num = num + Integer.parseInt(nowNum);

            Log.d(TAG, "showTabList: " + num);

            new QBadgeView(getContext()).bindTarget(((ViewGroup) tlTabs.getChildAt(0)).getChildAt(1))
                    .setBadgeNumber(num)
                    .setGravityOffset(50, 0, true)
                    .setOnDragStateChangedListener(new Badge.OnDragStateChangedListener() {
                        @Override
                        public void onDragStateChanged(int dragState, Badge badge, View targetView) {
                            if (dragState == 5) {
                                User user = new User();
                                user.setBadge("0");
                                user.update(getContext(), User.getCurrentUser(getContext(), User.class).getObjectId(), new UpdateListener() {
                                    @Override
                                    public void onSuccess() {

                                    }

                                    @Override
                                    public void onFailure(int i, String s) {

                                    }
                                });
                            }
                        }
                    });
        }*/


    }

    /**
     * fragment 打开 DrawerLayout 监听
     */
    public interface OnOpenDrawerLayoutListener {
        void onOpen();
    }
}
