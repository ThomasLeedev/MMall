package course.leedev.cn.pubgassistant.base;

/**
 * Created by lt on 2017/12/21.
 *
 * base model 接口
 */

public interface IBaseModel {
}
