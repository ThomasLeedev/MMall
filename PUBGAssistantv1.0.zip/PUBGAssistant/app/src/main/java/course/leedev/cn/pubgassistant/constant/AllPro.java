package course.leedev.cn.pubgassistant.constant;

import android.content.Context;

import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobUser;
import course.leedev.cn.pubgassistant.base.activity.BaseActivity;
import course.leedev.cn.pubgassistant.model.User;

/**
 * Created by lt on 18-5-28.
 */

public class AllPro {

    private static User user = null;

    public static User getUser(Context context) {
        user = (User) BmobUser.getCurrentUser(context);
        return user;
    }

}
