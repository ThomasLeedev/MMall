package course.leedev.cn.pubgassistant.model;

import cn.bmob.v3.BmobUser;

/**
 * Created by lt on 2018/1/9.
 */

public class User extends BmobUser {

    private String nickname;
    private String avatar;
    private String badge;
    private String address;
    private String qq;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq;
    }

    public String getBadge() {
        return badge;
    }

    public void setBadge(String badge) {
        this.badge = badge;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }
}
