package course.leedev.cn.pubgassistant.ui.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.text.InputType;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.afollestad.materialdialogs.Theme;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.vondear.rxtools.RxActivityTool;

import java.util.Observable;

import butterknife.BindView;
import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;
import cn.bmob.v3.listener.UpdateListener;
import course.leedev.cn.pubgassistant.R;
import course.leedev.cn.pubgassistant.base.activity.BaseActivity;
import course.leedev.cn.pubgassistant.constant.AllPro;
import course.leedev.cn.pubgassistant.model.User;
import course.leedev.cn.pubgassistant.service.MyService;
import io.reactivex.Observer;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;
import shem.com.materiallogin.DefaultLoginView;
import shem.com.materiallogin.DefaultRegisterView;
import shem.com.materiallogin.MaterialLoginView;

/**
 * Created by lt on 2018/1/9.
 */

public class LoginActivity extends BaseActivity {

    @BindView(R.id.login_et_username)
    EditText etUsername;
    @BindView(R.id.login_et_pass)
    EditText etPassword;
    @BindView(R.id.login_btn_login)
    Button btnLogin;
    @BindView(R.id.login_btn_register)
    Button btnRegister;

    User user = new User();

    @Override
    protected int getLayoutId() {
        return R.layout.activity_login;
    }

    @Override
    protected void initView(final Bundle savedInstanceState) {
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                user.setUsername(etUsername.getText().toString());
                user.setPassword(etPassword.getText().toString());
                user.login(LoginActivity.this, new SaveListener() {
                    @Override
                    public void onSuccess() {
                        startActivity(new Intent(LoginActivity.this, MainActivity.class));
                        finish();
                    }

                    @Override
                    public void onFailure(int i, String s) {
                        Toast.makeText(mApplication, "登录失败", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
                /*MaterialDialog materialDialog = new MaterialDialog.Builder(LoginActivity.this)
                        .title("注册用户")
                        .customView(R.layout.item_dialog_register, true)
                        .positiveText("确定")
                        .onPositive(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                View layout = dialog.getCustomView();
                                EditText etRegisterNick = layout.findViewById(R.id.register_et_nick);
                                EditText etRegisterUsername = layout.findViewById(R.id.register_et_username);
                                EditText etRegisterPass = layout.findViewById(R.id.register_et_pass);
                                TextView tvRegister = layout.findViewById(R.id.register_tv);

                                if (etRegisterNick.getText().toString().equals("") || etRegisterUsername.getText().toString().equals("") || etRegisterPass.getText().toString().equals("")) {
                                    Toast.makeText(mApplication, "注册失败", Toast.LENGTH_SHORT).show();
                                } else {
                                    user.setUsername(etRegisterUsername.getText().toString());
                                    user.setPassword(etRegisterPass.getText().toString());
                                    user.setNickname(etRegisterNick.getText().toString());
                                    user.signUp(mContext, new SaveListener() {
                                        @Override
                                        public void onSuccess() {
                                            Toast.makeText(mApplication, "注册成功", Toast.LENGTH_SHORT).show();
                                        }

                                        @Override
                                        public void onFailure(int i, String s) {
                                            Toast.makeText(mApplication, "注册失败" + s, Toast.LENGTH_SHORT).show();
                                        }
                                    });

                                }
                            }
                        })
                        .negativeText("取消")
                        .cancelable(false)
                        .show();*/
            }
        });

        /*btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new MaterialDialog.Builder(LoginActivity.this)
                        .title("修改密码")
                        .customView(R.layout.item_dialog_update, true)
                        .positiveText("确定")
                        .onPositive(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                View layout = dialog.getCustomView();
                                EditText etUpdateUsername = layout.findViewById(R.id.update_et_username);
                                EditText etUpdateOldPass = layout.findViewById(R.id.update_et_oldpass);
                                EditText etUpdateNewPass = layout.findViewById(R.id.update_et_newpass);

                                if (etUpdateUsername.getText().toString().equals("") || etUpdateOldPass.getText().toString().equals("") || etUpdateNewPass.getText().toString().equals("")) {
                                    Toast.makeText(mApplication, "修改失败", Toast.LENGTH_SHORT).show();
                                } else {
                                    BmobUser.updateCurrentUserPassword(mContext, etUpdateOldPass.getText().toString(), etUpdateNewPass.getText().toString(), new UpdateListener() {
                                        @Override
                                        public void onSuccess() {
                                            Toast.makeText(mApplication, "修改成功", Toast.LENGTH_SHORT).show();
                                        }

                                        @Override
                                        public void onFailure(int i, String s) {
                                            Toast.makeText(mApplication, "修改失败", Toast.LENGTH_SHORT).show();
                                        }
                                    });

                                }
                            }
                        })
                        .negativeText("取消")
                        .cancelable(false)
                        .show();
            }
        });*/

/*
        ((DefaultLoginView) loginView.getLoginView()) .setListener(new DefaultLoginView.DefaultLoginViewListener() {
            @Override
            public void onLogin(TextInputLayout loginUser, TextInputLayout loginPass) {
                user.setUsername(loginUser.getEditText().getText().toString());
                user.setPassword(loginPass.getEditText().getText().toString());
                user.login(LoginActivity.this, new SaveListener() {
                    @Override
                    public void onSuccess() {
                        Toast.makeText(mApplication, "登录成功", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onFailure(int i, String s) {
                        Toast.makeText(mApplication, "登录失败", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        ((DefaultRegisterView)loginView.getRegisterView()).setListener(new DefaultRegisterView.DefaultRegisterViewListener() {
            @Override
            public void onRegister(TextInputLayout registerUser, TextInputLayout registerPass, TextInputLayout registerPassRep) {
                Toast.makeText(mApplication, "抱歉，暂不开放注册！", Toast.LENGTH_SHORT).show();
            }
        });*/
    }
}
